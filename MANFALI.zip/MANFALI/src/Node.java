import java.util.*;
public class Node {
	
    String name;
    String fname;
    String cnic;
    String phnum;
    String tbltype;
    String type;
    String from;
    String to;
    String tnum;
    String seat;
    String chargeprseat;
    String tax;
    String ttl_bill;
    String expen;
	Node next;
}
