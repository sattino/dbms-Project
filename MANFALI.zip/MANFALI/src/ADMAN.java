import java.awt.EventQueue;
import java.util.Properties;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;

import javax.swing.JLabel;

import java.awt.Font;
import java.awt.Color;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JLayeredPane;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.*;

import javax.swing.border.MatteBorder;

import com.jtattoo.plaf.smart.SmartLookAndFeel;

import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ADMAN {
	private static JFrame frmHi;
	private final JPanel panel = new JPanel();
	private JTextField usertext;
	private JPasswordField passtext;
	private JTextField input;
	 static String name;
	    static String fname;
	    static String cnic;
	    static String phoneno;
	    static int id;
	    static String tbltype;
	    static String type;
	    static String from;
	    static String to;
	    static String tnum;
	    static String seat;
	    static String chargeprseat;
	    static String tax;
	    static String ttl_bill;
	    static String expen;
	    static Linklist l=new Linklist();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mfa","root","");
			String query="SELECT * FROM maindetails";
			Statement s=con.createStatement();
			ResultSet rs=s.executeQuery(query);
			while(rs.next())
			{
				//id=rs.getInt("Id");
				name=rs.getString("Name");
				fname=rs.getString("Father Name");   
				cnic=rs.getString("Cnic No");
				phoneno=rs.getString("Phone Number");
				tbltype=rs.getString("Table Type");
				type=rs.getString("Type");
				from=rs.getString("Timing(From)");   
				to=rs.getString("Timing(To)");
				tnum=rs.getString("Table Num");
				seat=rs.getString("Seat No");
				chargeprseat=rs.getString("ChargePerSeat");
				tax=rs.getString("Tax");   
				ttl_bill=rs.getString("TotalBill");
				expen=rs.getString("Expenditure");
				l.insertfromDataBaseUD(name,fname,cnic,phoneno,tbltype,type,from,to,tnum,seat,chargeprseat,tax,ttl_bill,expen);
			}
			if (!con.isClosed())
				System.out.println("COnncetion is true");
		}catch (Exception e)
		{
			System.err.println("Exception: "+e.getMessage());
		}
		finally{
			try {
				if(con!=null)
					con.close();
			}
			catch (SQLException e)
			{
				
			}
		}
		System.out.println(id);
		System.out.println(name);
		System.out.println(fname);
		System.out.println(cnic);
		System.out.println(phoneno);
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ADMAN window = new ADMAN();
			
					window.frmHi.setVisible(true);
					frmHi.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ADMAN() {
		/*try {
			/* Properties props = new Properties();
	            
	            props.put("logoString", "my company"); 
	            props.put("licenseKey", "INSERT YOUR LICENSE KEY HERE");
	            
	            props.put("selectionBackgroundColor", "180 240 197"); 
	            props.put("menuSelectionBackgroundColor", "180 240 197"); 
	            
	            props.put("controlColor", "218 254 230");
	            props.put("controlColorLight", "218 254 230");
	            props.put("controlColorDark", "180 240 197"); 

	            props.put("buttonColor", "218 230 254");
	            props.put("buttonColorLight", "255 255 255");
	            props.put("buttonColorDark", "244 242 232");

	            props.put("rolloverColor", "218 254 230"); 
	            props.put("rolloverColorLight", "218 254 230"); 
	            props.put("rolloverColorDark", "180 240 197"); 

	            props.put("windowTitleForegroundColor", "0 0 0");
	            props.put("windowTitleBackgroundColor", "180 240 197"); 
	            props.put("windowTitleColorLight", "218 254 230"); 
	            props.put("windowTitleColorDark", "180 240 197"); 
	            props.put("windowBorderColor", "218 254 230");*/
	            
	            // set your theme
	          //  SmartLookAndFeel.setCurrentTheme(props);
	            // select the Look and Feel
		//	UIManager.setLookAndFeel("com.jtattoo.plaf.smart.SmartLookAndFeel");
		/*} catch (ClassNotFoundException | InstantiationException
				| IllegalAccessException | UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frmHi = new JFrame();
		frmHi.setBackground(new Color(0, 100, 0));
		frmHi.setForeground(new Color(0, 0, 128));
		frmHi.setTitle("ADMIN ");
		
		frmHi.setBounds(100, 100, 483, 335);
		frmHi.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmHi.getContentPane().setLayout(null);
		panel.setBorder(new MatteBorder(4, 4, 4, 4, (Color) Color.BLACK));
		panel.setForeground(new Color(0, 0, 0));
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(0, 0, 473, 296);
		frmHi.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("          MANFALI RESTUARANT");
		lblNewLabel.setBounds(0, 0, 438, 61);
		lblNewLabel.setBackground(new Color(218, 165, 32));
		lblNewLabel.setForeground(new Color(218, 165, 32));
		lblNewLabel.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 28));
		panel.add(lblNewLabel);
		final JPanel panel_1 = new JPanel();
		panel_1.setBorder(new MatteBorder(4, 4, 4, 4, (Color) new Color(0, 0, 0)));
		panel_1.setBounds(0, 52, 473, 244);
		panel.add(panel_1);
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setLayout(null);
		panel_1.setVisible(false);
		final JButton btnNewButton = new JButton("ADMIN ");
	
		btnNewButton.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					panel_1.setVisible(true);
					btnNewButton.setVisible(false);
				}
			}
		});
		btnNewButton.setBounds(152, 125, 130, 37);
		btnNewButton.setForeground(new Color(128, 0, 0));
		final JPanel panel_3=new JPanel();
		btnNewButton.setFont(new Font("Jokerman", Font.BOLD | Font.ITALIC, 20));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panel_1.setVisible(true);
				btnNewButton.setVisible(false);
			//	new mani().button.setVisible(false);
			//	new mani().panel.setBackground(Color.black);
			}

			private void setVisible(boolean b) {
				// TODO Auto-generated method stub
				
			}
		});
		panel.add(btnNewButton);
		
		JLayeredPane layeredPane = new JLayeredPane();
		layeredPane.setBounds(10, 235, 394, -226);
		panel.add(layeredPane);
		
	
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBorder(new MatteBorder(2, 2, 2, 2, (Color) new Color(0, 0, 0)));
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setIcon(new ImageIcon(ADMAN.class.getResource("admin.png")));
		lblNewLabel_1.setBounds(0, 0, 214, 285);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("USER NAME");
		lblNewLabel_2.setForeground(new Color(23,164,184));
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel_2.setBounds(229, 19, 106, 35);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("PASSWORD");
		lblNewLabel_3.setForeground(new Color(23,164,184));
		lblNewLabel_3.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel_3.setBounds(235, 63, 100, 35);
		panel_1.add(lblNewLabel_3);
		
		usertext = new JTextField();
		passtext = new JPasswordField();
		passtext.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					if(evt.getKeyCode()==KeyEvent.VK_ENTER){
						input.requestFocus();
					}else if(evt.getKeyCode()==KeyEvent.VK_DOWN){
						input.requestFocus();
					}
				}else if(evt.getKeyCode()==KeyEvent.VK_UP){
				       usertext.requestFocus();
					}
			}
		});
		usertext.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					passtext.requestFocus();
				}else if(evt.getKeyCode()==KeyEvent.VK_ESCAPE){
					btnNewButton.setVisible(true);
					panel_1.setVisible(false);
				}else if(evt.getKeyCode()==KeyEvent.VK_DOWN){
					passtext.requestFocus();
				}
			}}
		);
		usertext.setBounds(345, 24, 100, 29);
		panel_1.add(usertext);
		usertext.setColumns(10);
		
		
		passtext.setBounds(345, 69, 100, 26);
		panel_1.add(passtext);
		Random rand = new Random();
		 int v=rand.nextInt(10000);
		 final String r=String.valueOf(v);
		
		final JButton btnNewButton_2 = new JButton("CANCEL");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnNewButton_2.setBackground(new Color(24,53,76));
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				btnNewButton_2.setBackground(Color.DARK_GRAY);
			}
		});
		btnNewButton_2.setBackground(Color.DARK_GRAY);
		btnNewButton_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
				panel_1.setVisible(false);
				btnNewButton.setVisible(true);
				btnNewButton.requestFocus();
				}
			}
		});
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panel_1.setVisible(false);
				btnNewButton.setVisible(true);
				
			}
		});
		btnNewButton_2.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 18));
		btnNewButton_2.setBounds(347, 199, 106, 23);
		panel_1.add(btnNewButton_2);
		
		JLabel lblNewLabel_4 = new JLabel("Enter the captcha");
		lblNewLabel_4.setForeground(new Color(24,53,76));
		lblNewLabel_4.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_4.setBounds(234, 109, 171, 23);
		panel_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnNewButton_2.setBackground(Color.GREEN);
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				btnNewButton_2.setBackground(Color.DARK_GRAY);
			}
		});
		lblNewLabel_5.setBounds(683, 146, -210, 87);
		panel_1.add(lblNewLabel_5);
		
		final JButton btnNewButton_1 = new JButton("OK");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnNewButton_1.setBackground(Color.green);
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				btnNewButton_1.setBackground(Color.DARK_GRAY);
			}
		});
		btnNewButton_1.setBackground(Color.DARK_GRAY);
		btnNewButton_1.addKeyListener(new KeyAdapter() {
			@Override
				public void keyPressed(KeyEvent evt) {
					if(evt.getKeyCode()==KeyEvent.VK_ENTER){
						String uname=usertext.getText();
						String  upass=passtext.getText();
						
						if(uname.equals("MANFALI")& upass.equals("CHOTAYLALA"))
						{
							new mani();
							
						}else if(!uname.equals("MANFALI") && !upass.equals("CHOTAYLALA"))
						{
							JOptionPane.showMessageDialog(null, "  kuch sahi daal");	
						}else if(!upass.equals("CHOTAYLALA"))
						{
							JOptionPane.showMessageDialog(null, "  sahi PASSWORD daal");
						}else if(!uname.equals("MANFALI"))
						{
							JOptionPane.showMessageDialog(null, "  kuch USERNAME daal");
						}
			
					}else if(evt.getKeyCode()==KeyEvent.VK_UP){
						passtext.requestFocus();
					}
			}
		});
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String uname=usertext.getText();
				String  upass=passtext.getText();
				String y = input.getText();
				if(uname.equals("MANFALI")& upass.equals("CHOTAYLALA") & y.equals(r))
				{
					new mani();
					
					
				}else if(!uname.equals("MANFALI") && !upass.equals("CHOTAYLALA"))
				{
					JOptionPane.showMessageDialog(null, "Both values are incorrect");	
				}else if(!upass.equals("CHOTAYLALA"))
				{
					JOptionPane.showMessageDialog(null, "Password is incorrect");
				}else if(!uname.equals("MANFALI"))
				{
					JOptionPane.showMessageDialog(null, "Username is incorrect");
				}else if(y != r)
				{
					JOptionPane.showMessageDialog(null, "Captcha is incorrect ");
				}
			}
		});
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(247, 143, 198, 45);
		panel_1.add(panel_4);
		panel_4.setLayout(null);
		JLabel ll = new JLabel("");
		ll.setBounds(10, 11, 64, 26);
		panel_4.add(ll);
		ll.setBorder(new MatteBorder(2, 2, 2, 2, (Color) Color.DARK_GRAY));
		ll.setBackground(new Color(23,164,184));
		ll.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent arg0) {
			}
		});
		ll.setFont(new Font("Serif", Font.BOLD, 16));
		//System.out.println("" + v );
		ll.setText(r);
		
		input = new JTextField();
		input.setBounds(92, 13, 78, 26);
		panel_4.add(input);
		
		
		input.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER)
				{
				
					String y = input.getText();
					if(!(y.equals(r)))
					{
						JOptionPane.showMessageDialog(null, " Sahi captch daal ");
					}else 
					{
						btnNewButton_1.requestFocus();
					}
				}
			}
		});
		String T = input.getText();
		input.setColumns(10);
		btnNewButton_1.setFont(new Font("Serif", Font.BOLD, 15));
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBounds(254, 199, 89, 23);
		panel_1.add(btnNewButton_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.BLACK);
		panel_2.setBounds(0, 52, 473, 244);
		panel.add(panel_2);
		
		JButton button = new JButton("?");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String msg="Click for admin :\n  Enter username in USERNAME field :\n  Enter Password in PASSWORD field\n Enter the same number as in box in CAPTCHA field \n  ";
				JOptionPane.showMessageDialog(null, msg);
			}
		});
		button.setForeground(Color.WHITE);
		button.setBackground(Color.DARK_GRAY);
		button.setBounds(426, 11, 37, 23);
		panel.add(button);
	}

	private static Color rgb(int i, int j, int k) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
