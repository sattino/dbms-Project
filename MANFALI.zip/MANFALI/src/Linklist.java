
public class Linklist{
	Node head;
    
	public void insert(String var1,String var2,String var3,String var4,String var5,String var6,String var7,String var8,String var9,String var10,String var11,String var12,String var13,String var14)
	{
		
		
		Node node = new Node();
		
		node.name=var1;
		node.fname=var2;
		node.cnic=var3;
		node.phnum=var4;
		node.tbltype=var5;
		node.type=var6;
		node.tnum=var7;
		node.from=var8;
		node.to=var9;
		node.seat=var10;
		node.chargeprseat=var11;
		node.tax=var12;
		node.ttl_bill=var13;
		node.expen=var14;
		node.next=null;
		//"INSERT INTO `maindetails` (`ID`, `Name`, `Father Name`, `Cnic No`, `Phone Number`, `Table type`, `Type`, `Timing(From)`, `Timing(To)`, `Table Num`, `Seat No`, `ChargePerSeat`, `Tax`, `TotalBill`, `Expenditure`) VALUES (NULL, '"+node.name+"', '"+node.fname+"', '"+node.cnic+"', '"+node.phnum+"','"+node.tbltype+"','"+node.type+"','"+node.tnum+"','"+node.from+"','"+node.to+"','"+node.seat+"','"+node.chargeprseat+"','"+node.tax+"','"+node.ttl_bill+"','"+expense+"' 
		//INSERT INTO `maindetails`(`ID`, `Name`, `Father Name`, `Cnic No`, `Phone Number`, `Table type`, `Type`, `Timing(From)`, `Timing(To)`, `Table Num`, `Seat No`, `ChargePerSeat`, `Tax`, `TotalBill`, `Expenditure`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6],[value-7],[value-8],[value-9],[value-10],[value-11],[value-12],[value-13],[value-14],[value-15])
		try
		{	
			System.out.println("bawa g");
		 DatabaseManager db=new DatabaseManager ("INSERT INTO `maindetails`( `Name`, `Father Name`, `Cnic No`, `Phone Number`, `Table type`, `Type`, `Timing(From)`, `Timing(To)`, `Table Num`, `Seat No`, `ChargePerSeat`, `Tax`, `TotalBill`, `Expenditure`) VALUES ('"+node.name+"','"+node.fname+"','"+node.cnic+"','"+node.phnum+"','"+node.tbltype+"','"+node.type+"','"+node.tnum+"','"+node.from+"','"+node.to+"','"+node.seat+"','"+node.chargeprseat+"','"+node.tax+"','"+node.ttl_bill+"','"+node.expen+"') ") ;
		}
		catch (NumberFormatException nfe)
		{
		  System.out.println("NumberFormatException: " + nfe.getMessage());
		}
	if(head == null)
	{
		head= node;
			
	}
	else  
	{
		Node n = head;
		while(n.next!=null)
			
		{
			n=n.next;
		}
		n.next=node;
	}
	}
public void show()
 {
    Node node = head; 
   /* while(node!=null)
    {
    	
    		System.out.println(node.name);
    		System.out.println(node.fname);
    		System.out.println(node.cnic);
    		System.out.println(node.phnum);
    		System.out.println(node.tbltype);
    		System.out.println(node.type);
    		System.out.println(node.from);
    		System.out.println(node.to);
    		System.out.println(node.tnum);
    		System.out.println(node.seat);
    		System.out.println(node.tax);
    		System.out.println(node.chargeprseat);
    		System.out.println(node.ttl_bill);
    		System.out.println(node.expen);
    	
    	node=node.next;
	
    }*/
    System.out.println(node.name);
	System.out.println(node.fname);
	System.out.println(node.cnic);
	System.out.println(node.phnum);
	System.out.println(node.tbltype);
	System.out.println(node.type);
	System.out.println(node.from);
	System.out.println(node.to);
	System.out.println(node.tnum);
	System.out.println(node.seat);
	System.out.println(node.tax);
	System.out.println(node.chargeprseat);
	System.out.println(node.ttl_bill);
	System.out.println(node.expen);
 }

public void searchUser(String name)
{
	Node node=head;
	for(node = head;node.next!=null&&node.name.equals(name);node=node.next)
	{
		System.out.print(node.name);
		System.out.print(node.fname);
		System.out.print(node.tnum);
		System.out.print(node.from);
		System.out.print(node.to);
		System.out.print(node.ttl_bill);
		
	
	}
	if(node.next==null&&node.name.equals(name))
	{
		System.out.print(node.name);
		System.out.print(node.fname);
		System.out.print(node.tnum);
		System.out.print(node.ttl_bill);
	}else if(!(node.name.equals(name)))
	{
	System.out.println("Name not found");
	}
	}
public void searchTable(String tnm)
{
	Node node;
	for(node = head;node.next!=null&&node.tnum.equals(tnm);node=node.next)
	{
		System.out.print(node.name);
		System.out.print(node.fname);
		System.out.print(node.cnic);
		System.out.print(node.phnum);
	
	}
	if(node.next==null&&node.tnum.equals(tnm))
	{
		System.out.print(node.name);
		System.out.print(node.fname);
		System.out.print(node.cnic);
		System.out.print(node.phnum);
	}else if(!(node.tnum.equals(tnm)))
	{
	System.out.println("Name not found");
	}
	}

public void insertAtStart(String name,String fname,String cnic,String phnum)
{
	Node node = new Node();
	node.name=name;
	node.fname=fname;
	node.cnic=cnic;
	node.phnum=phnum;
	node.next=null;
	node.next=head;
	head=node;
}

public void insertAtMiddle(String name,String fname,String cnic,String phnum,int index)
{
	
	Node node = new Node();
	node.name=name;
	node.fname=fname;
	node.cnic=cnic;
	node.phnum=phnum;
	node.next=null;
	Node n=head;
	if(index==0)
	{
		insertAtStart( name,fname,cnic,phnum);
	}else{
	for(int i=0;i<index-1;i++)
	{
		n=n.next;
	}
	node.next=n.next;
	n.next=node;
	}
}
public void deleteAtMiddle(int index)
{
	if(index==0)
	{
		head=head.next;
	}else
	{
		Node n=head;
		Node n1=null;
		for(int i=0;i<index-1;i++)
		{
			n=n.next;
		}
		n1=n.next;
		n.next=n1.next;
	}
}


public void insertfromDataBaseUD(String var1,String var2,String var3,String var4,String var5,String var6,String var7,String var8,String var9,String var10,String var11,String var12,String var13,String var14)
{
	
	
	Node node = new Node();
	node.name=var1;
	node.fname=var2;
	node.cnic=var3;
	node.phnum=var4;
	node.tbltype=var5;
	node.type=var6;
	node.tnum=var7;
	node.from=var8;
	node.to=var9;
	node.seat=var10;
	node.chargeprseat=var11;
	node.tax=var12;
	node.ttl_bill=var13;
	node.expen=var14;
	
	node.next=null;
	
if(head == null)
{
	head= node;
		
}
else  
{
	Node n = head;
	while(n.next!=null)
		
	{
		n=n.next;
	}
	n.next=node;
}
System.out.println(node.name);
	System.out.println(node.fname);
	System.out.println(node.cnic);
	System.out.println(node.phnum);
	System.out.println(node.tbltype);
	System.out.println(node.type);
	System.out.println(node.from);
	System.out.println(node.to);
	System.out.println(node.tnum);
	System.out.println(node.seat);
	System.out.println(node.tax);
	System.out.println(node.chargeprseat);
	System.out.println(node.ttl_bill);
	System.out.println(node.expen);
}
}
/*try
{	
	System.out.println("bawa g");
 DatabaseManager db=new DatabaseManager ("INSERT INTO `user record` (`Id`, `Name`, `Father Name`, `Cnic No.`, `Phone Number`) VALUES (NULL, '"+name+"', '"+fname+"', '"+cnic+"', '"+phnum+"');") ;							     							     
}
catch (NumberFormatException nfe)
{
  System.out.println("NumberFormatException: " + nfe.getMessage());
}*/