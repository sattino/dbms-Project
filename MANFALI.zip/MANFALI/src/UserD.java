import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import com.jtattoo.plaf.smart.SmartLookAndFeel;
import com.mysql.jdbc.Connection;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;

import java.awt.Cursor;
import java.util.Properties;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class UserD extends JDialog {

    static String tnum = null;
	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
    static String name;
    static String fname;
    static String cnic;
    static String phoneno;
	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		try {
			 Properties props = new Properties();
	            
	            props.put("logoString", "my company"); 
	            props.put("licenseKey", "INSERT YOUR LICENSE KEY HERE");
	            
	            props.put("selectionBackgroundColor", "180 240 197"); 
	            props.put("menuSelectionBackgroundColor", "180 240 197"); 
	            
	            props.put("controlColor", "218 254 230");
	            props.put("controlColorLight", "218 254 230");
	            props.put("controlColorDark", "180 240 197"); 

	            props.put("buttonColor", "218 230 254");
	            props.put("buttonColorLight", "255 255 255");
	            props.put("buttonColorDark", "244 242 232");

	            props.put("rolloverColor", "218 254 230"); 
	            props.put("rolloverColorLight", "218 254 230"); 
	            props.put("rolloverColorDark", "180 240 197"); 

	            props.put("windowTitleForegroundColor", "0 0 0");
	            props.put("windowTitleBackgroundColor", "180 240 197"); 
	            props.put("windowTitleColorLight", "218 254 230"); 
	            props.put("windowTitleColorDark", "180 240 197"); 
	            props.put("windowBorderColor", "218 254 230");
	            
	            // set your theme
	            SmartLookAndFeel.setCurrentTheme(props);
	            // select the Look and Feel
			UIManager.setLookAndFeel("com.jtattoo.plaf.smart.SmartLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException| IllegalAccessException | UnsupportedLookAndFeelException e) {
			
			e.printStackTrace();
		}
		try {
			
			UserD dialog = new UserD( );
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public UserD() {
		getContentPane().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		setUndecorated(true);
		setFont(new Font("SansSerif", Font.PLAIN, 12));
		((JComponent) getContentPane()).setBorder(BorderFactory.createLineBorder(Color.black));
		setBounds(100, 100, 450, 282);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new MatteBorder(4, 4, 4, 4, (Color) new Color(0, 0, 0)));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setBackground(new Color(255, 255, 255));
		getContentPane().setBackground(new Color(153, 153, 153));
		final JComboBox comboBox = new JComboBox();
		comboBox.setBorder(new LineBorder(new Color(153, 153, 153), 1, true));
		comboBox.setForeground(Color.BLACK);
		comboBox.setBackground(new Color(255, 255, 255));
		final JComboBox combooBox = new JComboBox();
		combooBox.setForeground(Color.BLACK);
		combooBox.setBackground(new Color(255, 255, 255));
		combooBox.setBorder(new LineBorder(new Color(171, 173, 179), 1, true));
		combooBox.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_LEFT){
					comboBox.requestFocus();
				}else if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
					textField_2.requestFocus();
				}
			}
		});
		comboBox.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
					combooBox.requestFocus();
				}
			}
		});
		final JButton btnCancel = new JButton("Reset");
		btnCancel.setFont(new Font("Serif", Font.BOLD, 16));
		btnCancel.setForeground(Color.WHITE);
		btnCancel.setBorder(new LineBorder(new Color(153, 153, 153)));
		btnCancel.setBackground(Color.DARK_GRAY);
		final JButton okButton = new JButton("OK");
		okButton.setFont(new Font("Serif", Font.BOLD, 16));
		okButton.setForeground(Color.WHITE);
		okButton.setBorder(new LineBorder(Color.DARK_GRAY, 1, true));
		okButton.setBackground(Color.DARK_GRAY);
		
		
		contentPanel.setLayout(null);
		{
			JLabel lblUsername = new JLabel("Name");
			lblUsername.setForeground(new Color(24,53,76));
			lblUsername.setFont(new Font("SansSerif", Font.BOLD, 14));
			lblUsername.setBounds(82, 55, 74, 20);
			contentPanel.add(lblUsername);
		}
		
		textField = new JTextField();
		textField.setBorder(new LineBorder(new Color(153, 153, 153), 1, true));
		textField_3 = new JTextField();
		textField_3.setBorder(new LineBorder(new Color(153, 153, 153), 1, true));
		textField_3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					String opt=textField_3.getText();
					if(((opt != null)&& (!opt.equals("")) && (opt.matches("[a-zA-Z ]+"))))
			        {
						textField_1.requestFocus();
			        }else 
			        {
			        	JOptionPane.showMessageDialog(null, "Father Name should only be in letters");
			        }
					
				}
			}
		});
		 final String line;
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					String opt=textField.getText();
				
					if(((opt != null)&& (!opt.equals("")) && (opt.matches("[a-zA-Z ]+"))))
			        {
						textField_3.requestFocus();
			        }else
			        {
			        	JOptionPane.showMessageDialog(null, "Name should only be in letters");
			        }
			       
					
				}
				
			}
		});
		textField.setBounds(209, 55, 163, 25);
		contentPanel.add(textField);
		textField.setColumns(10);
		{
			JLabel lblUserDetails = new JLabel("User Details");
			lblUserDetails.setForeground(new Color(24,53,76));
			lblUserDetails.setFont(new Font("SansSerif", Font.BOLD, 19));
			lblUserDetails.setBounds(174, 11, 122, 33);
			contentPanel.add(lblUserDetails);
		}
		{
			JLabel lblAddress = new JLabel("CNIC No.");
			lblAddress.setForeground(new Color(24,53,76));
			lblAddress.setFont(new Font("SansSerif", Font.BOLD, 14));
			lblAddress.setBounds(82, 117, 74, 20);
			contentPanel.add(lblAddress);
		}
		{
			
			textField_1 = new JTextField();
			textField_1.setBorder(new LineBorder(new Color(153, 153, 153), 1, true));
			textField_1.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent evt) {
					if(evt.getKeyCode()==KeyEvent.VK_ENTER){
						String text=textField_1.getText();
						if (text.matches("[0-9]+") && text.length() == 13) {
						    comboBox.requestFocus();
						}else
						{
							JOptionPane.showMessageDialog(null, "CNIC should only be in numbers \n without dashes \n with 13 numbers");
						}
						}
				}
			});
			textField_1.setBounds(209, 119, 163, 20);
			contentPanel.add(textField_1);
			textField_1.setColumns(10);
		}
		{
			JLabel lblPhoneNo = new JLabel("Phone No.");
			lblPhoneNo.setForeground(new Color(24,53,76));
			lblPhoneNo.setFont(new Font("SansSerif", Font.BOLD, 14));
			lblPhoneNo.setBounds(82, 179, 74, 20);
			contentPanel.add(lblPhoneNo);
		}
		{
			
			comboBox.setModel(new DefaultComboBoxModel(new String[] {"+92", "+971"}));
			comboBox.setBounds(209, 181, 51, 20);
			contentPanel.add(comboBox);
		}
		{
			
			combooBox.setModel(new DefaultComboBoxModel(new String[] {"300", "301", "302", "303", "304", "305", "306", "307", "308", "309", "310", "311", "312", "313", "314", "315", "316", "317", "318", "319", "320", "321", "322", "323", "324", "325", "326", "327", "328", "329", "330", "331", "332", "333", "334", "335", "336", "337", "338", "339", "340", "341", "342", "343", "344", "345", "346", "347", "348", "349", "350"}));
			combooBox.setBounds(257, 181, 51, 20);
			contentPanel.add(combooBox);
		}
		{
			textField_2 = new JTextField();
			textField_2.setBorder(new LineBorder(new Color(171, 173, 179), 1, true));
			textField_2.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent evt) {
					if(evt.getKeyCode()==KeyEvent.VK_ENTER){
						String text=textField_1.getText();
						if (text.matches("[0-9]+") && text.length() == 7) {
							okButton.requestFocus();
						}else
						{
							JOptionPane.showMessageDialog(null, "Phone number should only be in numbers \n without symbols \n with 7 numbers");
						}
						}
						
					
				}
			});
			textField_2.setBounds(301, 181, 82, 20);
			contentPanel.add(textField_2);
			textField_2.setColumns(10);
		}
		{
			JLabel lblInputWithoutDashes = new JLabel("Input without dashes e.g 1234567");
			lblInputWithoutDashes.setForeground(new Color(23,162,184));
			lblInputWithoutDashes.setFont(new Font("SansSerif", Font.ITALIC, 13));
			lblInputWithoutDashes.setBounds(82, 148, 205, 20);
			contentPanel.add(lblInputWithoutDashes);
		}
		{
			JLabel lblFatherName = new JLabel("Father Name");
			lblFatherName.setForeground(new Color(24,53,76));
			lblFatherName.setFont(new Font("SansSerif", Font.BOLD, 14));
			lblFatherName.setBounds(82, 86, 98, 20);
			contentPanel.add(lblFatherName);
		}
		{
			
			textField_3.setColumns(10);
			textField_3.setBounds(209, 88, 163, 20);
			contentPanel.add(textField_3);
		}
		{
			JPanel panel = new JPanel();
			panel.setForeground(Color.WHITE);
			panel.setBackground(new Color(255, 255, 255));
			panel.setBounds(10, 210, 430, 58);
			contentPanel.add(panel);
			panel.setLayout(null);
			{
				
				okButton.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent evt) {
						if(evt.getKeyCode()==KeyEvent.VK_ENTER){
						this.setVisible(false);
						//new FINALFRAME().setVisible(true);
						}else if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
							btnCancel.requestFocus();
						}
						}

					private void setVisible(boolean b) {
						// TODO Auto-generated method stub
						
					}
				});
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						Linklist list=new Linklist();
						
						String opt=textField.getText();
						
						String optt=textField_3.getText();
						String texx=textField_1.getText();
						String option=(String)comboBox.getSelectedItem();
						String optionn=(String)combooBox.getSelectedItem();
						String tex=textField_2.getText();
						
					     
						option=option+optionn+tex;
						Final f=new Final(opt,optt,texx,option,"");
						f.userd(opt,optt,texx,option);
						f.passValues();
			
						//list.show();
						//cnic=Integer.parseInt(texx);
						System.out.println(option);
						if(!((opt.matches("[a-zA-Z ]+"))))
				        {
							JOptionPane.showMessageDialog(null, "Name should only be in letters");
				        }else if(!((optt != null)&& (!optt.equals("")) && (optt.matches("[a-zA-Z ]+"))))
				        {
				        	JOptionPane.showMessageDialog(null, "Father Name should only be in letters");
				        }else if (!(texx.matches("[0-9]+") && texx.length() == 13)) {
				        	JOptionPane.showMessageDialog(null, "CNIC should only be in numbers \n without dashes \n with 13 numbers");
						}else 
						if (!(tex.matches("[0-9]+") && tex.length() == 7)) {
							JOptionPane.showMessageDialog(null, "Phone number should only be in numbers \n without symbols \n with 7 numbers");
						}else
						{
							//list.insertUD(opt,optt, texx, option);
							 
							//list.show();
							 
							 JOptionPane.showMessageDialog(null, "yes");
							this.setVisible(false);
							//new FINALFRAME().setVisible(true);
						}
					}

					private void theQuery(String string) {
						// TODO Auto-generated method stub
						
					}

					private void setVisible(boolean b) {
						// TODO Auto-generated method stub
						
					}
				});
				okButton.setBounds(273, 11, 57, 23);
				panel.add(okButton);
			}
			{
				
				btnCancel.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						int opt=JOptionPane.showConfirmDialog(null,"Do you want to reset ?","Yes", JOptionPane.YES_NO_OPTION);
						if (opt==0)
						{
							
						dispose();
						new UserD().setVisible(true);
							 
						}
					}
					private void setVisible(boolean b) {
						// TODO Auto-generated method stub
					}
				});
				btnCancel.setBounds(340, 11, 80, 23);
				panel.add(btnCancel);
			}
		}
		{
			JButton button = new JButton("?");
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String msg= "  Enter NAME in name feild  :\n  Enter Father name in Father name field :\n  Enter CNIC no in CNIC field\n Enter the Phone no in phone no feild \n  ";
					JOptionPane.showMessageDialog(null, msg);
				}
			});
			button.setForeground(Color.WHITE);
			button.setBackground(Color.DARK_GRAY);
			button.setBounds(346, 11, 37, 23);
			contentPanel.add(button);
		}
		{
			final JButton button = new JButton("");
			button.setIcon(new ImageIcon(mani.class.getResource("logoff.jpeg")));
			button.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent arg0) {
					button.setIcon(new ImageIcon(mani.class.getResource("logoffHoverr.jpeg")));
				}
				@Override
				public void mouseExited(MouseEvent arg0) {
					button.setIcon(new ImageIcon(mani.class.getResource("logoff.jpeg")));
				}
			});
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					int opt=JOptionPane.showConfirmDialog(null,"Do you want to close the program?","Yes", JOptionPane.YES_NO_OPTION);
					if (opt==0)
					{
						
						System.exit(0);
						 
					}
				
				}
			});
			button.setBounds(393, 11, 37, 23);
			contentPanel.add(button);
		}
		//1234567891012
		//1234567
	}
}
