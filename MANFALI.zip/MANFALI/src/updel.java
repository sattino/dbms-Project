import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextField;
public class updel extends JFrame {
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					updel frame = new updel();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public updel() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 404, 483);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 11, 378, 422);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("New tab", null, panel, null);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(29, 11, 325, 70);
		panel_1.setLayout(null);
		panel_1.setBorder(null);
		panel_1.setBackground(Color.WHITE);
		panel.add(panel_1);
		
		JButton button = new JButton("Delete Table ");
		button.setForeground(Color.WHITE);
		button.setFont(new Font("Serif", Font.BOLD, 14));
		button.setBackground(Color.DARK_GRAY);
		button.setBounds(22, 22, 129, 37);
		panel_1.add(button);
		
		JButton button_1 = new JButton("Update Table");
		button_1.setForeground(Color.WHITE);
		button_1.setFont(new Font("Serif", Font.BOLD, 14));
		button_1.setBackground(Color.DARK_GRAY);
		button_1.setBounds(173, 22, 125, 37);
		panel_1.add(button_1);
		
		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setBounds(29, 125, 325, 258);
		panel.add(tabbedPane_1);
		
		JPanel panel_2 = new JPanel();
		tabbedPane_1.addTab("New tab", null, panel_2, null);
		panel_2.setLayout(null);
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBackground(Color.GRAY);
		panel_3.setBounds(0, 0, 320, 219);
		panel_2.add(panel_3);
		
		JLabel label = new JLabel("Search by Id");
		label.setBounds(10, 21, 100, 29);
		panel_3.add(label);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(120, 21, 113, 29);
		panel_3.add(textField);
		
		JButton button_2 = new JButton("Search");
		button_2.setBounds(243, 24, 72, 23);
		panel_3.add(button_2);
		
		JPanel panel_4 = new JPanel();
		tabbedPane_1.addTab("New tab", null, panel_4, null);
		panel_4.setLayout(null);
		
		JPanel panel_5 = new JPanel();
		panel_5.setLayout(null);
		panel_5.setBackground(Color.DARK_GRAY);
		panel_5.setBounds(-15, 0, 325, 61);
		panel_4.add(panel_5);
		
		JLabel label_1 = new JLabel("Search by ID:");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Serif", Font.BOLD, 14));
		label_1.setBounds(22, 23, 97, 25);
		panel_5.add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(129, 27, 97, 20);
		panel_5.add(textField_1);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setBounds(236, 26, 76, 23);
		panel_5.add(btnUpdate);
		
		JPanel panel_6 = new JPanel();
		panel_6.setLayout(null);
		panel_6.setBounds(-5, 50, 325, 169);
		panel_4.add(panel_6);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(135, 11, 149, 32);
		panel_6.add(label_2);
		
		JLabel label_3 = new JLabel("");
		label_3.setBounds(135, 36, 149, 32);
		panel_6.add(label_3);
		
		JLabel label_4 = new JLabel("");
		label_4.setBounds(135, 72, 149, 32);
		panel_6.add(label_4);
		
		JLabel label_5 = new JLabel("");
		label_5.setBounds(94, 134, 97, 24);
		panel_6.add(label_5);
		
		JLabel label_6 = new JLabel("");
		label_6.setBounds(187, 134, 110, 24);
		panel_6.add(label_6);
		
		JLabel label_7 = new JLabel("Name");
		label_7.setFont(new Font("Serif", Font.BOLD, 14));
		label_7.setBounds(10, 11, 125, 32);
		panel_6.add(label_7);
		
		JLabel label_8 = new JLabel("Father  Name");
		label_8.setFont(new Font("Serif", Font.BOLD, 14));
		label_8.setBounds(10, 36, 125, 32);
		panel_6.add(label_8);
		
		JLabel label_9 = new JLabel("Table Number");
		label_9.setFont(new Font("Serif", Font.BOLD, 14));
		label_9.setBounds(10, 72, 110, 32);
		panel_6.add(label_9);
		
		JLabel label_10 = new JLabel("Timing:");
		label_10.setFont(new Font("Serif", Font.BOLD, 14));
		label_10.setBounds(10, 101, 76, 24);
		panel_6.add(label_10);
		
		JLabel label_11 = new JLabel("From");
		label_11.setFont(new Font("Serif", Font.BOLD, 14));
		label_11.setBounds(10, 134, 74, 24);
		panel_6.add(label_11);
		
		JLabel label_12 = new JLabel("To");
		label_12.setFont(new Font("Serif", Font.BOLD, 14));
		label_12.setBounds(168, 134, 55, 24);
		panel_6.add(label_12);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(80, 19, 86, 20);
		panel_6.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(105, 48, 86, 20);
		panel_6.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(105, 79, 86, 20);
		panel_6.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(72, 134, 86, 20);
		panel_6.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(198, 134, 86, 20);
		panel_6.add(textField_6);
		
		JButton button_4 = new JButton("Update");
		button_4.setBounds(234, 60, 89, 23);
		panel_6.add(button_4);
	}
}
