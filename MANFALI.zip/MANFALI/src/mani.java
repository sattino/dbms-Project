import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.border.EmptyBorder;

import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JLayeredPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.UnsupportedLookAndFeelException;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.BorderLayout;

import javax.swing.border.MatteBorder;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.swing.UIManager;
import javax.swing.JToggleButton;
import javax.swing.border.LineBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.TitledBorder;

import com.jtattoo.plaf.smart.SmartLookAndFeel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.SystemColor;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class mani {
    Linklist list=new Linklist();
	static String val="";
	static String tax="";
	 static String name;
	    static String fname;
	    static String cnic;
	    static String phoneno;
	    static int id;
	    static String tbltype;
	    static String type;
	    static String from;
	    static String to;
	    static String tnum;
	    static String seat;
	    static String chargeprseat;
	    
	    static String ttl_bill;
	    static String expen;
	    static Linklist  l =new Linklist();
    String option;
	public static UserD userd=new UserD();
	private static JFrame frmMainFrame;
	
	
	public final static JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
	final static JButton button = new JButton("");
	//button.setVisible(true);
	static JPanel panel;
	private JTabbedPane tabbedPane_3;
	private JTextField textname;
	private JTextField textField_2;
	private JTable tab1;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_7;
	private JTextField textField_8;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		// DatabaseManager databaseManager = new DatabaseManager( );
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				 Connection con = null;
				try {
					//Class.forName("com.mysql.jdbc.Driver").newInstance();
					//Class.forName ("com.mysql.jdbc.Driver");
					con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mfa","root","");
					Class.forName ("com.mysql.jdbc.Driver");
					String query="SELECT * FROM maindetails";
					Statement s=con.createStatement();
					ResultSet rs=s.executeQuery(query);
					while(rs.next())
					{
						//id=rs.getInt("Id");
						name=rs.getString("Name");
						fname=rs.getString("Father Name");   
						cnic=rs.getString("Cnic No");
						phoneno=rs.getString("Phone Number");
						tbltype=rs.getString("Table Type");
						type=rs.getString("Type");
						from=rs.getString("Timing(From)");   
						to=rs.getString("Timing(To)");
						tnum=rs.getString("Table Num");
						seat=rs.getString("Seat No");
						chargeprseat=rs.getString("ChargePerSeat");
						tax=rs.getString("Tax");   
						ttl_bill=rs.getString("TotalBill");
						expen=rs.getString("Expenditure");
						l.insertfromDataBaseUD(name,fname,cnic,phoneno,tbltype,type,from,to,tnum,seat,chargeprseat,tax,ttl_bill,expen);
					}
					if (!con.isClosed())
						System.out.println("COnncetion is true");
				}catch (Exception e)
				{
					System.err.println("Exception: "+e.getMessage());
				}
				finally{
					try {
						if(con!=null)
							con.close();
					}
					catch (SQLException e)
					{
						
					}
				}
			
		/*		try {
					 Properties props = new Properties();
			           
			           // props.put("logoString", "my company"); 
			           // props.put("licenseKey", "INSERT YOUR LICENSE KEY HERE");
					
			            props.put("selectionBackgroundColor", "180 240 197"); 
			            props.put("menuSelectionBackgroundColor", "180 240 197"); 
			            
			            props.put("controlColor", "218 254 230");
			            props.put("controlColorLight", "218 254 230");
			            props.put("controlColorDark", "180 240 197"); 

			            props.put("buttonColor", "218 230 254");
			            props.put("buttonColorLight", "255 255 255");
			          //  props.put("buttonColorDark", "244 242 232");

			            props.put("rolloverColor", "218 254 230"); 
			            props.put("rolloverColorLight", "218 254 230"); 
			            props.put("rolloverColorDark", "180 240 197"); 

			            props.put("windowTitleForegroundColor", "0 0 0");
			            props.put("windowTitleBackgroundColor", "180 240 197"); 
			            props.put("windowTitleColorLight", "218 254 230"); 
			            props.put("windowTitleColorDark", "180 240 197"); 
			            props.put("windowBorderColor", "218 254 230");
			            
			            // set your theme
			            SmartLookAndFeel.setCurrentTheme(props);
			            // select the Look and Feel
					UIManager.setLookAndFeel("com.jtattoo.plaf.smart.SmartLookAndFeel");
				} catch (ClassNotFoundException | InstantiationException
						| IllegalAccessException | UnsupportedLookAndFeelException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
				try {
					mani window = new mani();
					//button.setVisible(true);
					window.frmMainFrame.setVisible(true);
					 frmMainFrame.setResizable(false);
					
					button.addMouseListener(new MouseAdapter() {
							@Override
							public void mouseEntered(MouseEvent arg0) {
								button.setIcon(new ImageIcon(mani.class.getResource("TableHOver.jpeg")));
							}
							@Override
							public void mouseExited(MouseEvent arg0) {
								button.setIcon(new ImageIcon(mani.class.getResource("tab.jpg")));
							}
					});
					button.setBounds(0, 0, 188, 172);
					panel.add(button);
					button.setIcon(new ImageIcon(mani.class.getResource("tab.jpg")));
					button.requestFocus();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 */
	public mani()  {
		initialize();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings("rawtypes")
	private void initialize() {
		frmMainFrame = new JFrame();
		frmMainFrame.setTitle("Main Frame");
		frmMainFrame.setVisible(true);
		frmMainFrame.setBounds(100, 100, 641, 437);
		frmMainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Already there
		//frmMainFrame.setUndecorated(true);
		frmMainFrame.getContentPane().setLayout(null);
		panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.RAISED, new Color(128, 0, 0), new Color(0, 128, 128)));
		panel.setLayout(null);
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(26, 57, 188, 330);
		frmMainFrame.getContentPane().add(panel);
		frmMainFrame.getContentPane().setBackground(Color.DARK_GRAY);
		String vale;
		final JButton button_1 = new JButton("USER DETAIL");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_1.setIcon(new ImageIcon(mani.class.getResource("userHover.jpeg")));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_1.setIcon(new ImageIcon(mani.class.getResource("ali abbas.jpg")));
			}
		});
		button_1.setIcon(new ImageIcon(mani.class.getResource("ali abbas.jpg")));
		final JButton btnNewButton_3 = new JButton("Delete Table ");
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnNewButton_3.setBackground(new Color(24,53,76));
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				btnNewButton_3.setBackground(Color.DARK_GRAY);
			}
		});
		btnNewButton_3.setFont(new Font("Serif", Font.BOLD, 14));
		btnNewButton_3.setBackground(Color.DARK_GRAY);
		btnNewButton_3.setForeground(Color.WHITE);
		final JPanel panel_15 = new JPanel();
		panel_15.setBackground(new Color(128, 128, 128));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panel_15.setVisible(true);
				tab1.setVisible(true);
			}
		});
		final JButton btnNewButton_4 = new JButton("Update Table");
		btnNewButton_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnNewButton_4.setBackground(new Color(24,53,76));
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				btnNewButton_4.setBackground(Color.DARK_GRAY);
			}
		});
		btnNewButton_4.setFont(new Font("Serif", Font.BOLD, 14));
		btnNewButton_4.setForeground(Color.WHITE);
		btnNewButton_4.setBackground(Color.DARK_GRAY);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panel_15.setVisible(true);
			}
		});
		
		btnNewButton_4.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_LEFT){
					
					btnNewButton_3.requestFocus();
				}else if(evt.getKeyCode()==KeyEvent.VK_ENTER){
							
							panel_15.setVisible(true);
							}
			}
		});
		
		btnNewButton_3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
					
					btnNewButton_4.requestFocus();
				}else if(evt.getKeyCode()==KeyEvent.VK_ENTER){
							
							panel_15.setVisible(true);
							}
			}
		});
		final JButton button_7 = new JButton("Search By Table");
		button_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_7.setBackground(new Color(23,162,184));
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_7.setBackground(Color.DARK_GRAY);
			}
		});
		final JButton button_5 = new JButton("Search by Name");
		button_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_5.setBackground(new Color(23,162,184));
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_5.setBackground(Color.DARK_GRAY);
			}
		});
		
		button_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					tabbedPane.setSelectedIndex(2);
					button_7.requestFocus();
					}else if(evt.getKeyCode()==KeyEvent.VK_DOWN){
						
						//button_2.requestFocus();
						}else if(evt.getKeyCode()==KeyEvent.VK_UP){
							
							button.requestFocus();
							}
			}
		});
		final JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		final JComboBox comboBox = new JComboBox();
		comboBox.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			}
		});
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				tabbedPane_1.setVisible(false);
				//button_4.setVisible(true);
				button_5.setVisible(true);
			//	button_6.setVisible(true);
				button_7.setVisible(true);
				//panel_3.setVisible(false);
				tabbedPane.setSelectedIndex(2);
				//lblNewLabel_2.setVisible(false);
			}
		});
		button.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					tabbedPane.setSelectedIndex(1);
					comboBox.requestFocus();
					}else if(evt.getKeyCode()==KeyEvent.VK_DOWN){
						button_1.requestFocus();
					}
			}
		});
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {	
				
				tabbedPane.setSelectedIndex(1);
			}
		});
		button.setForeground(Color.RED);
		button.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 14));
		button.setBorder(new EmptyBorder(10, 10, 10, 10));
		button.setBackground(new Color(24,53,73));
		button_1.setForeground(Color.RED);
		button_1.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 14));
		button_1.setBorder(new EmptyBorder(10, 10, 10, 10));
		
		button_1.setBackground(Color.YELLOW);
		button_1.setBounds(0, 183, 188, 147);
		panel.add(button_1);
		
		JLabel label = new JLabel("ADMIN FUNCTIONS");
		label.setForeground(new Color(218, 165, 32));
		label.setFont(new Font("Serif", Font.BOLD, 20));
		label.setBorder(new EmptyBorder(10, 10, 10, 10));
		label.setBackground(Color.CYAN);
		label.setBounds(10, 12, 213, 34);
		frmMainFrame.getContentPane().add(label);
		
		
		tabbedPane.setBounds(225, 11, 379, 376);
		frmMainFrame.getContentPane().add(tabbedPane);
		
		JPanel panel_11 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_11, null);
		panel_11.setLayout(null);
		
		JLabel label_9 = new JLabel("New ");
		label_9.setIcon(new ImageIcon(mani.class.getResource("ssss.PNG")));
		label_9.setBounds(-18, -20, 440, 368);
		
		panel_11.add(label_9);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBackground(new Color(0, 0, 0));
		lblNewLabel_1.setBounds(0, 0, 374, 33);
		panel_11.add(lblNewLabel_1);
		/*tglbtnNewToggleButton.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent arg0) {
				tglbtnNewToggleButton.setBackground(new Color(255,255,255));
			}
		});*/
		
		final JTabbedPane tabbedPane_2 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_2.setVisible(false);
		
		comboBox.setBounds(150, 28, 89, 20);
		comboBox.setFont(new Font("Serif", Font.PLAIN, 12));
		comboBox.setBackground(Color.DARK_GRAY);
		comboBox.setForeground(Color.WHITE);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new MatteBorder(0, 0, 0, 0, (Color) new Color(0, 0, 0)));
		panel_2.setBackground(new Color(246,246,246));
		tabbedPane.addTab("New tab", null, panel_2, null);
		panel_2.setLayout(null);
		
		JLayeredPane layeredPane_1 = new JLayeredPane();
		layeredPane_1.setBounds(0, 341, 374, -338);
		panel_2.add(layeredPane_1);
		
		
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Family", "Bachelor"}));
		panel_2.add(comboBox);
		JLabel label_4 = new JLabel("Select type");
		label_4.setBounds(29, 27, 99, 20);
		label_4.setBackground(new Color(23,162,184));
		label_4.setForeground(new Color(23,162,184));
		label_4.setFont(new Font("Serif", Font.BOLD, 14));
		panel_2.add(label_4);
		
		JLabel label_5 = new JLabel("Table Type");
		label_5.setBounds(29, 69, 82, 23);
		label_5.setForeground(new Color(23,162,184));
		label_5.setFont(new Font("Serif", Font.BOLD, 14));
		panel_2.add(label_5);
		
		JLabel lblTimingdayhourminute = new JLabel("TABLE TIMING");
		lblTimingdayhourminute.setBounds(29, 114, 123, 23);
		lblTimingdayhourminute.setForeground(new Color(24,53,76));
		lblTimingdayhourminute.setFont(new Font("Serif", Font.BOLD, 16));
		lblTimingdayhourminute.setBackground(Color.CYAN);
		panel_2.add(lblTimingdayhourminute);
		
		JLabel label_7 = new JLabel("FROM");
		label_7.setBounds(29, 148, 55, 23);
		label_7.setForeground(new Color(23,162,184));
		label_7.setFont(new Font("Serif", Font.BOLD, 14));
		panel_2.add(label_7);
		
		JLabel label_8 = new JLabel("TO");
		label_8.setBounds(206, 152, 22, 18);
		label_8.setForeground(new Color(23,162,184));
		label_8.setFont(new Font("Stencil", Font.BOLD, 16));
		panel_2.add(label_8);
		
		final JButton button_13 = new JButton("OK");
		button_13.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_13.setBackground(Color.GREEN);
			}
			public void mouseExited(MouseEvent arg0) {
				button_13.setBackground(Color.DARK_GRAY);
			}
		});
		button_13.setBounds(104, 191, 61, 23);
		button_13.setFont(new Font("Serif", Font.BOLD, 16));
		button_13.setForeground(Color.WHITE);
		button_13.setBackground(Color.DARK_GRAY);
		button_13.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){

					option=(String)comboBox.getSelectedItem();
					if(option=="Family"&&type=="Standard")
					{
						DSeat d;
						d=new DSeat("200","50");
						
					}else if(option=="Bachelor"&&type=="Standard")
					{
						DSeat d;
						d=new DSeat("250","30");

					}
					if(option=="Family"&&type=="Premium")
					{
						DSeat d;
						d=new DSeat("400","90");

					}else if(option=="Bachelor"&&type=="Premium")
					{
						DSeat d;
						d=new DSeat("500","70");

					}
					if(type=="Standard")
					{
						tabbedPane_2.setVisible(true);
						tabbedPane_2.setSelectedIndex(0);
					}else if(type=="Premium")
					{
						tabbedPane_2.setVisible(true);
						tabbedPane_2.setSelectedIndex(1);
					}else
					{
						JOptionPane.showMessageDialog(null, "Select table type");
					}
					
					}
			}
		});
		button_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				option=(String)comboBox.getSelectedItem();
				if(option=="Family"&&type=="Standard")
				{
					DSeat d=new DSeat("200","50");
					
					//new DSeat(val);
				}else if(option=="Bachelor"&&type=="Standard")
				{
					DSeat d=new DSeat("250","30");
					//new DSeat().value=val;
				}
				if(option=="Family"&&type=="Premium")
				{
					DSeat d=new DSeat("400","90");
					//new DSeat(val);
					//new DSeat().value=val;
				}else if(option=="Bachelor"&&type=="Premium")
				{
					DSeat d=new DSeat("500","70");
					//new DSeat().value=val;
					//new DSeat(val);
				}
				if(type=="Standard")
				{
					
					tabbedPane_2.setVisible(true);
					tabbedPane_2.setSelectedIndex(0);
				}else if(type=="Premium")
				{
					tabbedPane_2.setVisible(true);
					tabbedPane_2.setSelectedIndex(1);
				}else
				{
					JOptionPane.showMessageDialog(null, "Select table type");
				}
				
			}
		});
		button_13.setBorder(null);
		panel_2.add(button_13);
		
		final JButton button_14 = new JButton("Cancel");
		button_14.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_14.setBackground(new Color(23,162,184));
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_14.setBackground(Color.DARK_GRAY);
			}
		});
		button_14.setBounds(193, 191, 89, 23);
		button_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tabbedPane.setSelectedIndex(1);
			}
		});
		button_14.setFont(new Font("Serif", Font.BOLD, 16));
		button_14.setBackground(Color.DARK_GRAY);
		button_14.setForeground(Color.WHITE);
		button_14.setBorder(new EmptyBorder(10, 10, 10, 10));
		panel_2.add(button_14);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(94, 150, 89, 20);
		comboBox_1.setFont(new Font("Serif", Font.PLAIN, 12));
		comboBox_1.setForeground(Color.WHITE);
		comboBox_1.setBackground(Color.DARK_GRAY);
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"12:00 a.m", "09:00 a.m", "10:00 a.m", "11:00 a.m", "12:00 p.m", "01:00 p.m", "02:00 p.m", "03:00 p.m", "04:00 p.m", "05:00 p.m", "06:00 p.m", "07:00 p.m", "08:00 p.m", "09:00 p.m", "10:00 p.m", "11:00 p.m"}));
		panel_2.add(comboBox_1);
		
		final JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(249, 150, 89, 20);
		comboBox_2.setFont(new Font("Serif", Font.PLAIN, 12));
		comboBox_2.setBackground(Color.DARK_GRAY);
		comboBox_2.setForeground(Color.WHITE);
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"12:00 a.m", "09:00 a.m", "10:00 a.m", "11:00 a.m", "12:00 p.m", "01:00 p.m", "02:00 p.m", "03:00 p.m", "04:00 p.m", "05:00 p.m", "06:00 p.m", "07:00 p.m", "08:00 p.m", "09:00 p.m", "10:00 p.m", "11:00 p.m"}));
		panel_2.add(comboBox_2);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBounds(0, 225, 374, 23);
		panel_2.add(panel_7);
		
		
		tabbedPane_2.setBounds(41, 225, 275, 117);
		panel_2.add(tabbedPane_2);
		final JPanel panel_10 = new JPanel();
		tabbedPane_2.addTab("", null, panel_10, null);
		tabbedPane_2.setEnabledAt(0, false);
		panel_10.setVisible(false);
		
		
		panel_10.setBackground(new Color(24,53,76));
		
		final JButton button_15 = new JButton("1");
		button_15.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_15.setBackground(new Color(255,255,255));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_15.setBackground(new Color(246, 246, 246));
			}
		});
		button_15.setBounds(28, 5, 49, 35);
		final JButton button_16 = new JButton("2");
		button_16.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_16.setBackground(new Color(255,255,255));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_16.setBackground(new Color(246, 246, 246));
			}
		});
		button_16.setBounds(116, 5, 48, 35);
		final JButton button_17 = new JButton("3");
		button_17.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_17.setBackground(new Color(255,255,255));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_17.setBackground(new Color(246, 246, 246));
			}
		});
		button_17.setBounds(196, 5, 49, 35);
		final JButton button_19 = new JButton("4");
		button_19.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_19.setBackground(new Color(255,255,255));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_19.setBackground(new Color(246, 246, 246));
			}
		});
		button_19.setBounds(28, 50, 49, 33);
		final JButton button_20 = new JButton("5");
		button_20.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_20.setBackground(new Color(255,255,255));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_20.setBackground(new Color(246, 246, 246));
			}
		});
		button_20.setBounds(116, 51, 49, 31);
		final JButton button_21 = new JButton("6");
		button_21.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_21.setBackground(new Color(255,255,255));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_21.setBackground(new Color(246, 246, 246));
			}
		});
		button_21.setBounds(196, 50, 49, 33);
		
		button_16.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					new DSeat(val,"").setVisible(true);
					
					button_16.setBackground(Color.green);
					 //dseat.value="200";
					 button_15.setBackground(Color.white);
					 button_17.setBackground(Color.white);
					// button_18.setBackground(Color.white);
					 button_19.setBackground(Color.white);
					 button_20.setBackground(Color.white);
					 button_21.setBackground(Color.white);
					// button_22.setBackground(Color.white);
					// button_23.setBackground(Color.white);
				//	 button_24.setBackground(Color.white);
				}else if(evt.getKeyCode()==KeyEvent.VK_LEFT){
					button_15.requestFocus();
				}else if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
					button_17.requestFocus();
				}
			}
		});
		
		button_17.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					new DSeat(val,"").setVisible(true);
					button_17.setBackground(Color.green);
					 //dseat.value="200";
					 button_15.setBackground(Color.white);
					 button_16.setBackground(Color.white);
					// button_18.setBackground(Color.white);
					 button_19.setBackground(Color.white);
					 button_20.setBackground(Color.white);
					 button_21.setBackground(Color.white);
					// button_22.setBackground(Color.white);
					// button_23.setBackground(Color.white);
					// button_24.setBackground(Color.white);
				}else if(evt.getKeyCode()==KeyEvent.VK_LEFT){
					button_16.requestFocus();
				}else if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
					//button_18.requestFocus();
				}
			}
		});
		button_19.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					new DSeat(val,tax).setVisible(true);
					button_19.setBackground(Color.green);
					 //dseat.value="200";
					 button_15.setBackground(Color.white);
					 button_16.setBackground(Color.white);
					// button_18.setBackground(Color.white);
					 button_17.setBackground(Color.white);
					 button_20.setBackground(Color.white);
					 button_21.setBackground(Color.white);
					 //button_22.setBackground(Color.white);
					// button_23.setBackground(Color.white);
					// button_24.setBackground(Color.white);
				}else if(evt.getKeyCode()==KeyEvent.VK_LEFT){
					//button_22.requestFocus();
				}else if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
					button_20.requestFocus();
				}
			}
		});
		button_20.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					new DSeat(val,"").setVisible(true);
					button_20.setBackground(Color.green);
					 //dseat.value="200";
					 button_15.setBackground(Color.white);
					 button_16.setBackground(Color.white);
					// button_18.setBackground(Color.white);
					 button_19.setBackground(Color.white);
					 button_21.setBackground(Color.white);
					 button_17.setBackground(Color.white);
					// button_22.setBackground(Color.white);
					// button_23.setBackground(Color.white);
					// button_24.setBackground(Color.white);
				}else if(evt.getKeyCode()==KeyEvent.VK_LEFT){
					button_19.requestFocus();
				}else if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
					button_21.requestFocus();
				}
			}
		});
		
		button_21.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					new DSeat(val,"").setVisible(true);
					button_21.setBackground(Color.green);
					 //dseat.value="200";
					 button_15.setBackground(Color.white);
					 button_16.setBackground(Color.white);
					// button_18.setBackground(Color.white);
					 button_19.setBackground(Color.white);
					 button_20.setBackground(Color.white);
					 button_17.setBackground(Color.white);
				//	 button_22.setBackground(Color.white);
					// button_23.setBackground(Color.white);
				//	 button_24.setBackground(Color.white);
				}else if(evt.getKeyCode()==KeyEvent.VK_LEFT){
					button_20.requestFocus();
				}else if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
				//	button_23.requestFocus();
				}
			}
		});
		button_15.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
				tnum="1";
				new DSeat(val,"").setVisible(true);
				button_15.setBackground(Color.green);
				 //dseat.value="200";
				 button_16.setBackground(Color.white);
				 button_17.setBackground(Color.white);
			//	 button_18.setBackground(Color.white);
				 button_19.setBackground(Color.white);
				 button_20.setBackground(Color.white);
				 button_21.setBackground(Color.white);
			//	 button_22.setBackground(Color.white);
			//	 button_23.setBackground(Color.white);
			//	 button_24.setBackground(Color.white);
				}if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
				  button_16.requestFocus();
				}
			}
		});
		
		
		button_21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String tbltype=(String)comboBox.getSelectedItem();
				String from=(String)comboBox_1.getSelectedItem();
				String to=(String)comboBox_2.getSelectedItem();
				String tnum="6";
				Final f=new Final(tbltype,type,from,to,tnum);
				if(option=="Family"&&type=="Standard")
				{
					DSeat d=new DSeat("200","50");
					d.setVisible(true);
					f.mani(tbltype,type,from,to,tnum);
					//new DSeat(val);
				}else if(option=="Bachelor"&&type=="Standard")
				{
					DSeat d=new DSeat("250","30");
					d.setVisible(true);
					//new DSeat().value=val;
					f.mani(tbltype,type,from,to,tnum);
				}
				if(option=="Family"&&type=="Premium")
				{
					DSeat d=new DSeat("400","90");
					d.setVisible(true);
					f.mani(tbltype,type,from,to,tnum);
					//new DSeat(val);
					//new DSeat().value=val;
				}else if(option=="Bachelor"&&type=="Premium")
				{
					DSeat d=new DSeat("500","70");
					d.setVisible(true);
					f.mani(tbltype,type,from,to,tnum);
					//new DSeat().value=val;
					//new DSeat(val);
				}
				button_21.setBackground(Color.green);
				 //dseat.value="200";
				 button_15.setBackground(Color.white);
				 button_16.setBackground(Color.white);
				// button_18.setBackground(Color.white);
				 button_19.setBackground(Color.white);
				 button_20.setBackground(Color.white);
				 button_17.setBackground(Color.white);
				// button_22.setBackground(Color.white);
				// button_23.setBackground(Color.white);
				// button_24.setBackground(Color.white);
			}
		});
		button_20.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String tbltype=(String)comboBox.getSelectedItem();
				String from=(String)comboBox_1.getSelectedItem();
				String to=(String)comboBox_2.getSelectedItem();
				String tnum="5";
				Final f=new Final(tbltype,type,from,to,tnum);
				if(option=="Family"&&type=="Standard")
				{
					DSeat d=new DSeat("200","50");
					d.setVisible(true);
					f.mani(tbltype,type,from,to,tnum);
					//new DSeat(val);
				}else if(option=="Bachelor"&&type=="Standard")
				{
					DSeat d=new DSeat("250","30");
					d.setVisible(true);
					//new DSeat().value=val;
					f.mani(tbltype,type,from,to,tnum);
				}
				if(option=="Family"&&type=="Premium")
				{
					DSeat d=new DSeat("400","90");
					d.setVisible(true);
					f.mani(tbltype,type,from,to,tnum);
					//new DSeat(val);
					//new DSeat().value=val;
				}else if(option=="Bachelor"&&type=="Premium")
				{
					DSeat d=new DSeat("500","70");
					d.setVisible(true);
					f.mani(tbltype,type,from,to,tnum);
					//new DSeat().value=val;
					//new DSeat(val);
				}
				button_20.setBackground(Color.green);
				 //dseat.value="200";
				 button_15.setBackground(Color.white);
				 button_16.setBackground(Color.white);
			//	 button_18.setBackground(Color.white);
				 button_19.setBackground(Color.white);
				 button_21.setBackground(Color.white);
				 button_17.setBackground(Color.white);
			//	 button_22.setBackground(Color.white);
				// button_23.setBackground(Color.white);
			//	 button_24.setBackground(Color.white);
			}
		});
		
		button_19.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String tbltype=(String)comboBox.getSelectedItem();
				String from=(String)comboBox_1.getSelectedItem();
				String to=(String)comboBox_2.getSelectedItem();
				String tnum="4";
				Final f=new Final(tbltype,type,from,to,tnum);
				if(option=="Family"&&type=="Standard")
				{
					DSeat d=new DSeat("200","50");
					d.setVisible(true);
					f.mani(tbltype,type,from,to,tnum);
					//new DSeat(val);
				}else if(option=="Bachelor"&&type=="Standard")
				{
					DSeat d=new DSeat("250","30");
					d.setVisible(true);
					//new DSeat().value=val;
					f.mani(tbltype,type,from,to,tnum);
				}
				if(option=="Family"&&type=="Premium")
				{
					DSeat d=new DSeat("400","90");
					d.setVisible(true);
					f.mani(tbltype,type,from,to,tnum);
					//new DSeat(val);
					//new DSeat().value=val;
				}else if(option=="Bachelor"&&type=="Premium")
				{
					DSeat d=new DSeat("500","70");
					d.setVisible(true);
					f.mani(tbltype,type,from,to,tnum);
					//new DSeat().value=val;
					//new DSeat(val);
				}
				
				button_19.setBackground(Color.green);
				 //dseat.value="200";
				 button_15.setBackground(Color.white);
				 button_16.setBackground(Color.white);
			//	 button_18.setBackground(Color.white);
				 button_17.setBackground(Color.white);
				 button_20.setBackground(Color.white);
				 button_21.setBackground(Color.white);
				// button_22.setBackground(Color.white);
			//	 button_23.setBackground(Color.white);
			//	 button_24.setBackground(Color.white);
			}
		});
		
			button_17.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String tbltype=(String)comboBox.getSelectedItem();
					String from=(String)comboBox_1.getSelectedItem();
					String to=(String)comboBox_2.getSelectedItem();
					String tnum="3";
					Final f=new Final(tbltype,type,from,to,tnum);
					if(option=="Family"&&type=="Standard")
					{
						DSeat d=new DSeat("200","50");
						d.setVisible(true);
						f.mani(tbltype,type,from,to,tnum);
						//new DSeat(val);
					}else if(option=="Bachelor"&&type=="Standard")
					{
						DSeat d=new DSeat("250","30");
						d.setVisible(true);
						//new DSeat().value=val;
						f.mani(tbltype,type,from,to,tnum);
					}
					if(option=="Family"&&type=="Premium")
					{
						DSeat d=new DSeat("400","90");
						d.setVisible(true);
						f.mani(tbltype,type,from,to,tnum);
						//new DSeat(val);
						//new DSeat().value=val;
					}else if(option=="Bachelor"&&type=="Premium")
					{
						DSeat d=new DSeat("500","70");
						d.setVisible(true);
						f.mani(tbltype,type,from,to,tnum);
						//new DSeat().value=val;
						//new DSeat(val);
					}
					
				//	obj.setVisible(true);
					button_17.setBackground(Color.green);
					 //dseat.value="200";
					 button_15.setBackground(Color.white);
					 button_16.setBackground(Color.white);
					// button_18.setBackground(Color.white);
					 button_19.setBackground(Color.white);
					 button_20.setBackground(Color.white);
					 button_21.setBackground(Color.white);
					// button_22.setBackground(Color.white);
					// button_23.setBackground(Color.white);
					// button_24.setBackground(Color.white);
				}
			});
			
			button_16.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String tbltype=(String)comboBox.getSelectedItem();
					String from=(String)comboBox_1.getSelectedItem();
					String to=(String)comboBox_2.getSelectedItem();
					String tnum="2";
					Final f=new Final(tbltype,type,from,to,tnum);
					if(option=="Family"&&type=="Standard")
					{
						DSeat d=new DSeat("200","50");
						d.setVisible(true);
						f.mani(tbltype,type,from,to,tnum);
						//new DSeat(val);
					}else if(option=="Bachelor"&&type=="Standard")
					{
						DSeat d=new DSeat("250","30");
						d.setVisible(true);
						//new DSeat().value=val;
						f.mani(tbltype,type,from,to,tnum);
					}
					if(option=="Family"&&type=="Premium")
					{
						DSeat d=new DSeat("400","90");
						d.setVisible(true);
						f.mani(tbltype,type,from,to,tnum);
						//new DSeat(val);
						//new DSeat().value=val;
					}else if(option=="Bachelor"&&type=="Premium")
					{
						DSeat d=new DSeat("500","70");
						d.setVisible(true);
						f.mani(tbltype,type,from,to,tnum);
						//new DSeat().value=val;
						//new DSeat(val);
					}
					
					button_16.setBackground(Color.green);
					// dseat.value="200";
					 button_15.setBackground(Color.white);
					 button_17.setBackground(Color.white);
				//	 button_18.setBackground(Color.white);
					 button_19.setBackground(Color.white);
					 button_20.setBackground(Color.white);
					 button_21.setBackground(Color.white);
				//	 button_22.setBackground(Color.white);
				//	 button_23.setBackground(Color.white);
				//	 button_24.setBackground(Color.white);
				}
			});
			
			
			button_15.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String tbltype=(String)comboBox.getSelectedItem();
					String from=(String)comboBox_1.getSelectedItem();
					String to=(String)comboBox_2.getSelectedItem();
					String tnum="1";
					Final f=new Final(tbltype,type,from,to,tnum);
					if(option=="Family"&&type=="Standard")
					{
						DSeat d=new DSeat("200","50");
						d.setVisible(true);
						f.mani(tbltype,type,from,to,tnum);
						//new DSeat(val);
					}else if(option=="Bachelor"&&type=="Standard")
					{
						DSeat d=new DSeat("250","30");
						d.setVisible(true);
						//new DSeat().value=val;
						f.mani(tbltype,type,from,to,tnum);
					}
					if(option=="Family"&&type=="Premium")
					{
						DSeat d=new DSeat("400","90");
						d.setVisible(true);
						f.mani(tbltype,type,from,to,tnum);
						//new DSeat(val);
						//new DSeat().value=val;
					}else if(option=="Bachelor"&&type=="Premium")
					{
						DSeat d=new DSeat("500","70");
						d.setVisible(true);
						f.mani(tbltype,type,from,to,tnum);
						//new DSeat().value=val;
						//new DSeat(val);
					}
					
					
					
					button_15.setBackground(Color.green);
					 //dseat.value="200";
					 button_16.setBackground(Color.white);
					 button_17.setBackground(Color.white);
					 //button_18.setBackground(Color.white);
					 button_19.setBackground(Color.white);
					 button_20.setBackground(Color.white);
					 button_21.setBackground(Color.white);
					// button_22.setBackground(Color.white);
					// button_23.setBackground(Color.white);
					// button_24.setBackground(Color.white);
				}
			});
			panel_10.setLayout(null);
			button_15.setBorder(new EmptyBorder(10, 10, 10, 10));
			button_15.setBackground(new Color(246, 246, 246));
			panel_10.add(button_15);
			button_16.setBorder(new EmptyBorder(10, 10, 10, 10));
			button_16.setBackground(new Color(246, 246, 246));
			panel_10.add(button_16);
			button_17.setBorder(new EmptyBorder(10, 10, 10, 10));
			button_17.setBackground(new Color(246, 246, 246));
			panel_10.add(button_17);
			button_19.setBorder(new EmptyBorder(10, 10, 10, 10));
			button_19.setBackground(new Color(246, 246, 246));
			panel_10.add(button_19);
			button_20.setBorder(new EmptyBorder(10, 10, 10, 10));
			button_20.setBackground(new Color(246, 246, 246));
			panel_10.add(button_20);
			button_21.setBackground(new Color(246, 246, 246));
			panel_10.add(button_21);
			
			JPanel panel_17 = new JPanel();
			panel_17.setBackground(Color.DARK_GRAY);
			tabbedPane_2.addTab("", null, panel_17, null);
			panel_17.setLayout(null);
			
			final JButton button_11 = new JButton("1");
			final JButton button_18 = new JButton("3");
			final JButton button_12 = new JButton("2");
			final JButton button_22 = new JButton("4");
			button_22.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String tbltype=(String)comboBox.getSelectedItem();
					String from=(String)comboBox_1.getSelectedItem();
					String to=(String)comboBox_2.getSelectedItem();
					String tnum="4";
					Final f=new Final(tbltype,type,from,to,tnum);
					if(option=="Family"&&type=="Standard")
					{
						DSeat d=new DSeat("200","50");
						d.setVisible(true);
						//new DSeat(val);
					}else if(option=="Bachelor"&&type=="Standard")
					{
						DSeat d=new DSeat("250","30");
						d.setVisible(true);
						//new DSeat().value=val;
					}
					if(option=="Family"&&type=="Premium")
					{
						DSeat d=new DSeat("400","90");
						d.setVisible(true);
						//new DSeat(val);
						//new DSeat().value=val;
					}else if(option=="Bachelor"&&type=="Premium")
					{
						DSeat d=new DSeat("500","70");
						d.setVisible(true);
						//new DSeat().value=val;
						//new DSeat(val);
					}
					
					 button_22.setBackground(Color.green);
					 button_12.setBackground(new Color(246, 246, 246));
					 button_18.setBackground(new Color(246, 246, 246));
					 button_11.setBackground(new Color(246, 246, 246));
				}
			});
			
			
			
			button_12.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String tbltype=(String)comboBox.getSelectedItem();
					String from=(String)comboBox_1.getSelectedItem();
					String to=(String)comboBox_2.getSelectedItem();
					String tnum="2";
					Final f=new Final(tbltype,type,from,to,tnum);
					if(option=="Family"&&type=="Standard")
					{
						DSeat d=new DSeat("200","50");
						d.setVisible(true);
						//new DSeat(val);
					}else if(option=="Bachelor"&&type=="Standard")
					{
						DSeat d=new DSeat("250","30");
						d.setVisible(true);
						//new DSeat().value=val;
					}
					if(option=="Family"&&type=="Premium")
					{
						DSeat d=new DSeat("400","90");
						d.setVisible(true);
						//new DSeat(val);
						//new DSeat().value=val;
					}else if(option=="Bachelor"&&type=="Premium")
					{
						DSeat d=new DSeat("500","70");
						d.setVisible(true);
						//new DSeat().value=val;
						//new DSeat(val);
					}
					
					 button_12.setBackground(Color.green);
					 button_22.setBackground(new Color(246, 246, 246));
					 button_18.setBackground(new Color(246, 246, 246));
					 button_11.setBackground(new Color(246, 246, 246));
				}
			});
			
			button_11.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					
					String tbltype=(String)comboBox.getSelectedItem();
					String from=(String)comboBox_1.getSelectedItem();
					String to=(String)comboBox_2.getSelectedItem();
					String tnum="1";
					Final f=new Final(tbltype,type,from,to,tnum);
					if(option=="Family"&&type=="Standard")
					{
						DSeat d=new DSeat("200","50");
						d.setVisible(true);
						//new DSeat(val);
					}else if(option=="Bachelor"&&type=="Standard")
					{
						DSeat d=new DSeat("250","30");
						d.setVisible(true);
						//new DSeat().value=val;
					}
					if(option=="Family"&&type=="Premium")
					{
						DSeat d=new DSeat("400","90");
						d.setVisible(true);
						//new DSeat(val);
						//new DSeat().value=val;
					}else if(option=="Bachelor"&&type=="Premium")
					{
						DSeat d=new DSeat("500","70");
						d.setVisible(true);
						//new DSeat().value=val;
						//new DSeat(val);
					}
					
					 button_11.setBackground(Color.green);
					 button_22.setBackground(new Color(246, 246, 246));
					 button_18.setBackground(new Color(246, 246, 246));
					 button_12.setBackground(new Color(246, 246, 246));
				}
			});
			button_11.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent arg0) {
					button_11.setBackground(new Color(255,255,255));
				}
				@Override
				public void mouseExited(MouseEvent arg0) {
					button_11.setBackground(new Color(246, 246, 246));
				}
			});
			button_11.setOpaque(false);
			button_11.setFocusPainted(false);
			button_11.setBorderPainted(false);
			//button_11.setContentAreaFilled(false);
			button_11.setBorder(BorderFactory.createEmptyBorder(0,0,0,0)); 
			//button_11.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
			button_11.setBackground(Color.WHITE);
			button_11.setBounds(50, 11, 52, 35);
			panel_17.add(button_11);
			
		
			button_12.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent arg0) {
					button_12.setBackground(new Color(255,255,255));
				}
				@Override
				public void mouseExited(MouseEvent arg0) {
					button_12.setBackground(new Color(246, 246, 246));
				}
			});
			button_12.setBorder(new EmptyBorder(10, 10, 10, 10));
			button_12.setBackground(new Color(220, 220, 220));
			button_12.setBounds(159, 11, 49, 35);
			panel_17.add(button_12);
			
			
			button_18.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent arg0) {
					button_18.setBackground(new Color(255,255,255));
				}
				@Override
				public void mouseExited(MouseEvent arg0) {
					button_18.setBackground(new Color(246, 246, 246));
				}
			});
			button_18.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String tbltype=(String)comboBox.getSelectedItem();
					String from=(String)comboBox_1.getSelectedItem();
					String to=(String)comboBox_2.getSelectedItem();
					String tnum="3";
					Final f=new Final(tbltype,type,from,to,tnum);
					if(option=="Family"&&type=="Standard")
					{
						DSeat d=new DSeat("200","50");
						d.setVisible(true);
						//new DSeat(val);
					}else if(option=="Bachelor"&&type=="Standard")
					{
						DSeat d=new DSeat("250","30");
						d.setVisible(true);
						//new DSeat().value=val;
					}
					if(option=="Family"&&type=="Premium")
					{
						DSeat d=new DSeat("400","90");
						d.setVisible(true);
						//new DSeat(val);
						//new DSeat().value=val;
					}else if(option=="Bachelor"&&type=="Premium")
					{
						DSeat d=new DSeat("500","70");
						d.setVisible(true);
						//new DSeat().value=val;
						//new DSeat(val);
					}
					
					 button_18.setBackground(Color.green);
					 button_22.setBackground(new Color(246, 246, 246));
					 button_12.setBackground(new Color(246, 246, 246));
					 button_11.setBackground(new Color(246, 246, 246));
				}
			});
			button_18.setBorder(new EmptyBorder(10, 10, 10, 10));
			button_18.setBackground(new Color(220, 220, 220));
			button_18.setBounds(50, 51, 52, 31);
			panel_17.add(button_18);
			
			
			button_22.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent arg0) {
					button_22.setBackground(new Color(255,255,255));
				}
				@Override
				public void mouseExited(MouseEvent arg0) {
					button_22.setBackground(new Color(246, 246, 246));
				}
			});
			button_22.setBorder(new EmptyBorder(10, 10, 10, 10));
			button_22.setBackground(new Color(220, 220, 220));
			button_22.setBounds(159, 51, 49, 31);
			panel_17.add(button_22);
			final JButton btnNewButton_6 = new JButton("Standard");
			btnNewButton_6.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
			
			final JButton btnNewButton_5 = new JButton("Premium");
			btnNewButton_5.setBackground(Color.DARK_GRAY);
			btnNewButton_5.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent arg0) {
					btnNewButton_5.setBackground(new Color(23,162,184));
				}
				public void mouseExited(MouseEvent arg0) {
					btnNewButton_5.setBackground(Color.DARK_GRAY);
				}
			});
			btnNewButton_5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					type="Premium";
					btnNewButton_5.setBackground(Color.YELLOW);
					btnNewButton_5.setBorder(new MatteBorder(2,2,2,2, (Color) Color.YELLOW));
					btnNewButton_6.setBackground(Color.DARK_GRAY);
					btnNewButton_6.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
				}
			});
			btnNewButton_5.setForeground(Color.WHITE);
			btnNewButton_5.setFont(new Font("Serif", Font.BOLD, 16));
			btnNewButton_5.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
			btnNewButton_5.setBounds(249, 69, 103, 23);
			panel_2.add(btnNewButton_5);
			
			
			btnNewButton_6.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					type="Standard";
					btnNewButton_6.setBackground(Color.YELLOW);
					btnNewButton_6.setBorder(new MatteBorder(2,2,2,2, (Color) Color.YELLOW));
					btnNewButton_5.setBackground(Color.DARK_GRAY);
					btnNewButton_5.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
				}
			});
			btnNewButton_6.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent arg0) {
					btnNewButton_6.setBackground(new Color(23,162,184));
				}
				
				@Override
				public void mouseExited(MouseEvent arg0) {
					btnNewButton_6.setBackground(Color.DARK_GRAY);
				}
			});
			btnNewButton_6.setBackground(Color.DARK_GRAY);
			btnNewButton_6.setForeground(Color.WHITE);
			btnNewButton_6.setFont(new Font("Serif", Font.BOLD, 16));
			btnNewButton_6.setBounds(140, 69, 99, 23);
			panel_2.add(btnNewButton_6);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new MatteBorder(4, 4, 4, 4, (Color) new Color(0, 0, 0)));
		panel_1.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("New tab", null, panel_1, null);
		
		final JLayeredPane layeredPane = new JLayeredPane();
		
		layeredPane.setBounds(0, 347, 374, -345);
		panel_1.setLayout(null);
		panel_1.add(layeredPane);
		
		
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tabbedPane_3.setVisible(true);
				tabbedPane_3.setSelectedIndex(0);
			}
		});
		button_5.setBounds(10, 38, 152, 31);
		button_5.setForeground(Color.WHITE);
		button_5.setFont(new Font("Serif", Font.BOLD, 16));
		button_5.setBackground(Color.DARK_GRAY);
		panel_1.add(button_5);
		
		
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tabbedPane_3.setVisible(true);
				tabbedPane_3.setSelectedIndex(1);
			}
		});
		button_7.setBounds(200, 38, 164, 31);
		button_7.setForeground(Color.WHITE);
		button_7.setFont(new Font("Serif", Font.BOLD, 16));
		button_7.setBackground(Color.DARK_GRAY);
		panel_1.add(button_7);
		
		//JTabbedPane tabbedPane_1;
		tabbedPane_3 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_3.setBounds(10, 80, 354, 89);
		tabbedPane_3.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		panel_1.add(tabbedPane_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.DARK_GRAY);
		tabbedPane_3.addTab("", null, panel_4, null);
		panel_4.setLayout(null);
		
		JLabel lblEnterName = new JLabel("Search by Name:");
		lblEnterName.setFont(new Font("Serif", Font.BOLD, 14));
		lblEnterName.setForeground(Color.WHITE);
		lblEnterName.setBounds(10, 23, 109, 25);
		panel_4.add(lblEnterName);
		
		textname = new JTextField();
		textname.setBounds(129, 27, 119, 20);
		panel_4.add(textname);
		textname.setColumns(10);
		
		
		final JLabel lname = new JLabel("");
		final JLabel lfname = new JLabel("");
		final JLabel ltnum = new JLabel("");
		final JLabel lfrom = new JLabel("");
		final JLabel lto = new JLabel("");
		final JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//list.insertUD("BALOLAY", "BALALOY KE DADDY", "123456", "1234567");
				String name=textname.getText();
				String query="SELECT * FROM `maindetails` WHERE Name";
				query=query+"="+"'"+name+"'";
				System.out.println(query);
				 Connection con = null;
					try {
						Class.forName("com.mysql.jdbc.Driver").newInstance();
						con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mfa","root","");
						
						PreparedStatement s=con.prepareStatement(query);
						//s.setString(2,textname.getText());
						ResultSet rs=s.executeQuery(query);
						while(rs.next())
						{
							//id=rs.getInt("Id");
								name=rs.getString("Name");
								lname.setText(name);
								fname=rs.getString("Father Name");   
								lfname.setText(fname);
								tnum=rs.getString("Table Num");
								ltnum.setText(tnum);
								from=rs.getString("Timing(From)"); 
								lfrom.setText(from);
								to=rs.getString("Timing(To)");
								lto.setText(to);
							
							
							/*cnic=rs.getString("Cnic No");
							phoneno=rs.getString("Phone Number");*/
							/*tbltype=rs.getString("Table Type");
							type=rs.getString("Type");
							
							
							seat=rs.getString("Seat No");
							chargeprseat=rs.getString("ChargePerSeat");
							tax=rs.getString("Tax");   
							ttl_bill=rs.getString("TotalBill");
							expen=rs.getString("Expenditure");
							l.insertfromDataBaseUD(name,fname,cnic,phoneno,tbltype,type,from,to,tnum,seat,chargeprseat,tax,ttl_bill,expen);*/
							
						}
						
						if (!con.isClosed())
							System.out.println("COnncetion is true");
					}catch (Exception e)
					{
						System.err.println("Exception: "+e.getMessage());
					}
					finally{
						try {
							if(con!=null)
								con.close();
						}
						catch (SQLException e)
						{
							
						}
					}
				
			}
		});
		btnSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnSearch.setBackground(new Color(23,162,184));
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				btnSearch.setBackground(Color.DARK_GRAY);
			}
		});
		btnSearch.setBounds(258, 26, 76, 23);
		panel_4.add(btnSearch);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(Color.GRAY);
		tabbedPane_3.addTab("", null, panel_6, null);
		panel_6.setLayout(null);
		
		JLabel lblSearchByTable = new JLabel("Search by Id");
		lblSearchByTable.setBounds(10, 21, 100, 29);
		panel_6.add(lblSearchByTable);
		
		textField_2 = new JTextField();
		textField_2.setBounds(120, 21, 113, 29);
		panel_6.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnSearch_1 = new JButton("Search");
		btnSearch_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tnum=" ";
				String txt=textField_2.getText();
				String query="SELECT * FROM `maindetails` WHERE `Table Num`";
				query=query+"="+"'"+txt+"'";
			
				 Connection con = null;
					try {
						Class.forName("com.mysql.jdbc.Driver").newInstance();
						con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mfa","root","");
						
						PreparedStatement s=con.prepareStatement(query);
						//s.setString(10,txt);
						ResultSet rs=s.executeQuery(query);
						while(rs.next())
						{
							//id=rs.getInt("Id");
								name=rs.getString("Name");
								lname.setText(name);
								fname=rs.getString("Father Name");   
								lfname.setText(fname);
								tnum=rs.getString("Table Num");
								ltnum.setText(tnum);
								from=rs.getString("Timing(From)"); 
								lfrom.setText(from);
								to=rs.getString("Timing(To)");
								lto.setText(to);
							
							
							/*cnic=rs.getString("Cnic No");
							phoneno=rs.getString("Phone Number");*/
							/*tbltype=rs.getString("Table Type");
							type=rs.getString("Type");
							
							
							seat=rs.getString("Seat No");
							chargeprseat=rs.getString("ChargePerSeat");
							tax=rs.getString("Tax");   
							ttl_bill=rs.getString("TotalBill");
							expen=rs.getString("Expenditure");
							l.insertfromDataBaseUD(name,fname,cnic,phoneno,tbltype,type,from,to,tnum,seat,chargeprseat,tax,ttl_bill,expen);*/
							
						}
						
						if (!con.isClosed())
							System.out.println("COnncetion is true");
					}catch (Exception e)
					{
						System.err.println("Exception: "+e.getMessage());
					}
					finally{
						try {
							if(con!=null)
								con.close();
						}
						catch (SQLException e)
						{
							
						}
					}
			}
		});
		btnSearch_1.setBounds(243, 24, 72, 23);
		panel_6.add(btnSearch_1);
		
		JLabel label_1 = new JLabel("User and Table Details");
		label_1.setBounds(109, 0, 188, 35);
		label_1.setForeground(Color.BLACK);
		label_1.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 18));
		panel_1.add(label_1);
		
		JPanel display = new JPanel();
		display.setBounds(10, 168, 354, 169);
		panel_1.add(display);
		display.setLayout(null);
		
		
		lname.setBounds(135, 11, 149, 32);
		display.add(lname);
		
		
		lfname.setBounds(135, 36, 149, 32);
		display.add(lfname);
		
		
		ltnum.setBounds(135, 72, 149, 32);
		display.add(ltnum);
		
		
		lfrom.setBounds(94, 134, 97, 24);
		display.add(lfrom);
		
		
		lto.setBounds(187, 134, 110, 24);
		display.add(lto);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Serif", Font.BOLD, 14));
		lblName.setBounds(10, 11, 125, 32);
		display.add(lblName);
		
		JLabel lblFatherName = new JLabel("Father  Name");
		lblFatherName.setFont(new Font("Serif", Font.BOLD, 14));
		lblFatherName.setBounds(10, 36, 125, 32);
		display.add(lblFatherName);
		
		JLabel lblTableNumber = new JLabel("Table Number");
		lblTableNumber.setFont(new Font("Serif", Font.BOLD, 14));
		lblTableNumber.setBounds(10, 72, 110, 32);
		display.add(lblTableNumber);
		
		JLabel lblTiming = new JLabel("Timing:");
		lblTiming.setFont(new Font("Serif", Font.BOLD, 14));
		lblTiming.setBounds(10, 101, 76, 24);
		display.add(lblTiming);
		
		JLabel lblFrom = new JLabel("From");
		lblFrom.setFont(new Font("Serif", Font.BOLD, 14));
		lblFrom.setBounds(10, 134, 74, 24);
		display.add(lblFrom);
		
		JLabel lblTo = new JLabel("To");
		lblTo.setFont(new Font("Serif", Font.BOLD, 14));
		lblTo.setBounds(168, 134, 55, 24);
		display.add(lblTo);
		
		JLayeredPane layeredPane_3 = new JLayeredPane();
		layeredPane_3.setBorder(new MatteBorder(4, 4, 4, 4, (Color) new Color(0, 0, 0)));
		layeredPane_3.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("New tab", null, layeredPane_3, null);
		layeredPane_3.setLayout(null);
		
		JPanel panel_13 = new JPanel();
		panel_13.setBackground(new Color(255, 255, 255));
		panel_13.setBorder(null);
		panel_13.setBounds(25, 11, 321, 70);
		layeredPane_3.add(panel_13);
		panel_13.setLayout(null);
		
		
		btnNewButton_3.setBounds(22, 22, 129, 37);
		panel_13.add(btnNewButton_3);
		
		
		btnNewButton_4.setBounds(173, 22, 125, 37);
		panel_13.add(btnNewButton_4);
		
		
		panel_15.setBounds(10, 92, 354, 256);
		layeredPane_3.add(panel_15);
		panel_15.setLayout(null);
		
		//table.setVisible(true);
		
		tab1 = new JTable();
		tab1.setBounds(0, 0, 354, -236);
		panel_15.add(tab1);
		
		tab1.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		
		JTabbedPane tabbedPane_4 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_4.setBounds(10, 21, 334, 235);
		panel_15.add(tabbedPane_4);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.GRAY);
		tabbedPane_4.addTab("New tab", null, panel_3, null);
		panel_3.setLayout(null);
		
		JLabel label_2 = new JLabel("Search by Id");
		label_2.setBounds(10, 21, 100, 29);
		panel_3.add(label_2);
		
		textField = new JTextField();
		textField.setBounds(120, 21, 113, 29);
		textField.setColumns(10);
		panel_3.add(textField);
		
		JButton button_2 = new JButton("Search");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		button_2.setBounds(243, 24, 72, 23);
		panel_3.add(button_2);
		
		JPanel panel_5 = new JPanel();
		tabbedPane_4.addTab("New tab", null, panel_5, null);
		panel_5.setLayout(null);
		
		JPanel panel_8 = new JPanel();
		panel_8.setLayout(null);
		panel_8.setBackground(Color.DARK_GRAY);
		panel_8.setBounds(0, 0, 349, 61);
		panel_5.add(panel_8);
		
		JLabel lblSearchById = new JLabel("Search by ID:");
		lblSearchById.setForeground(Color.WHITE);
		lblSearchById.setFont(new Font("Serif", Font.BOLD, 14));
		lblSearchById.setBounds(10, 23, 109, 25);
		panel_8.add(lblSearchById);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(129, 27, 97, 20);
		panel_8.add(textField_1);
		
		JButton button_3 = new JButton("Search");
		button_3.setBounds(236, 26, 76, 23);
		panel_8.add(button_3);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBounds(0, 60, 329, 147);
		panel_5.add(panel_9);
		panel_9.setLayout(null);
		
		JPanel panel_12 = new JPanel();
		panel_12.setBounds(164, 5, 1, 1);
		panel_12.setLayout(null);
		panel_9.add(panel_12);
		
		JLabel label_3 = new JLabel("");
		label_3.setBounds(135, 11, 149, 32);
		panel_12.add(label_3);
		
		JLabel label_6 = new JLabel("");
		label_6.setBounds(135, 36, 149, 32);
		panel_12.add(label_6);
		
		JLabel label_10 = new JLabel("");
		label_10.setBounds(135, 72, 149, 32);
		panel_12.add(label_10);
		
		JLabel label_11 = new JLabel("");
		label_11.setBounds(94, 134, 97, 24);
		panel_12.add(label_11);
		
		JLabel label_12 = new JLabel("");
		label_12.setBounds(187, 134, 110, 24);
		panel_12.add(label_12);
		
		JLabel label_13 = new JLabel("Name");
		label_13.setFont(new Font("Serif", Font.BOLD, 14));
		label_13.setBounds(10, 11, 125, 32);
		panel_12.add(label_13);
		
		JLabel label_14 = new JLabel("Father  Name");
		label_14.setFont(new Font("Serif", Font.BOLD, 14));
		label_14.setBounds(10, 36, 125, 32);
		panel_12.add(label_14);
		
		JLabel label_15 = new JLabel("Table Number");
		label_15.setFont(new Font("Serif", Font.BOLD, 14));
		label_15.setBounds(10, 72, 110, 32);
		panel_12.add(label_15);
		
		JLabel label_16 = new JLabel("Timing:");
		label_16.setFont(new Font("Serif", Font.BOLD, 14));
		label_16.setBounds(10, 101, 76, 24);
		panel_12.add(label_16);
		
		JLabel label_17 = new JLabel("From");
		label_17.setFont(new Font("Serif", Font.BOLD, 14));
		label_17.setBounds(10, 134, 74, 24);
		panel_12.add(label_17);
		
		JLabel label_18 = new JLabel("To");
		label_18.setFont(new Font("Serif", Font.BOLD, 14));
		label_18.setBounds(168, 134, 55, 24);
		panel_12.add(label_18);
		
		JPanel panel_14 = new JPanel();
		panel_14.setLayout(null);
		panel_14.setBounds(0, -12, 354, 169);
		panel_9.add(panel_14);
		
		JLabel label_19 = new JLabel("");
		label_19.setBounds(135, 11, 149, 32);
		panel_14.add(label_19);
		
		JLabel label_20 = new JLabel("");
		label_20.setBounds(135, 36, 149, 32);
		panel_14.add(label_20);
		
		JLabel label_21 = new JLabel("");
		label_21.setBounds(135, 72, 149, 32);
		panel_14.add(label_21);
		
		JLabel label_22 = new JLabel("");
		label_22.setBounds(94, 134, 97, 24);
		panel_14.add(label_22);
		
		JLabel label_23 = new JLabel("");
		label_23.setBounds(187, 134, 110, 24);
		panel_14.add(label_23);
		
		JLabel label_24 = new JLabel("Name");
		label_24.setFont(new Font("Serif", Font.BOLD, 14));
		label_24.setBounds(10, 11, 125, 32);
		panel_14.add(label_24);
		
		JLabel label_25 = new JLabel("Father  Name");
		label_25.setFont(new Font("Serif", Font.BOLD, 14));
		label_25.setBounds(10, 36, 125, 32);
		panel_14.add(label_25);
		
		JLabel label_26 = new JLabel("Table Number");
		label_26.setFont(new Font("Serif", Font.BOLD, 14));
		label_26.setBounds(10, 72, 110, 32);
		panel_14.add(label_26);
		
		JLabel label_27 = new JLabel("Timing:");
		label_27.setFont(new Font("Serif", Font.BOLD, 14));
		label_27.setBounds(10, 101, 76, 24);
		panel_14.add(label_27);
		
		JLabel label_28 = new JLabel("From");
		label_28.setFont(new Font("Serif", Font.BOLD, 14));
		label_28.setBounds(10, 134, 74, 24);
		panel_14.add(label_28);
		
		JLabel label_29 = new JLabel("To");
		label_29.setFont(new Font("Serif", Font.BOLD, 14));
		label_29.setBounds(168, 134, 55, 24);
		panel_14.add(label_29);
		
		textField_3 = new JTextField();
		textField_3.setBounds(80, 19, 86, 20);
		panel_14.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(105, 48, 86, 20);
		panel_14.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(105, 79, 86, 20);
		panel_14.add(textField_5);
		textField_5.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(72, 134, 86, 20);
		panel_14.add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setBounds(198, 134, 86, 20);
		panel_14.add(textField_8);
		textField_8.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Update");
		btnNewButton_1.setBounds(234, 60, 89, 23);
		panel_14.add(btnNewButton_1);
	}

	private Color setColor(int i, int j, int k) {
		// TODO Auto-generated method stub
		return null;
	}


	public void NewScreen() {
		// TODO Auto-generated method stub
		
	}

	public void setEnabled(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
