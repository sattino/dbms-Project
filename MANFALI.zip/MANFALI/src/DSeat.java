import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.BevelBorder;
import javax.swing.UIManager;

import com.mysql.jdbc.Statement;

import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;


@SuppressWarnings("serial")
public class DSeat extends JDialog {


	private final JPanel contentPanel = new JPanel();
	 
	 static String value;
	 String expen;
	 String seatno;
	 static String tax;
	 static String ttl_bill;
	/**
	 * Launch the application.
	 */
//	public DSeat()
//	 {
//		 chprseat.setText();
//	 }
	public static void main(String[] args) {
		//DatabaseManager databaseManager = new DatabaseManager( );
		try {
			DSeat dialog = new DSeat(value,tax);
			
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	 
	/**
	 * Create the dialog.
	 * @return 
	 */
	 final JLabel ttlseat = new JLabel(" ");
	
	
	int total_bill=0;
	final JLabel ttlbill = new JLabel("");
	
	public DSeat(final String val,final String tax) {
		
		setTitle("Bill box");
		setUndecorated(true);
		//JOptionPane.showMessageDialog(null, value);
		setBounds(100, 100, 401, 313);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(255, 255, 255));
		contentPanel.setBorder(new MatteBorder(4, 4, 4, 4, (Color) new Color(0, 0, 0)));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblSelectNumberOf = new JLabel("Select number of seats:");
			lblSelectNumberOf.setBackground(new Color(0, 0, 0));
			lblSelectNumberOf.setForeground(new Color(24,53,76));
			lblSelectNumberOf.setFont(new Font("SansSerif", Font.BOLD, 16));
			lblSelectNumberOf.setBounds(20, 36, 224, 21);
			contentPanel.add(lblSelectNumberOf);
		}
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(57, 57, 296, 69);
		contentPanel.add(panel);
		panel.setBackground(new Color(24,53,76));
		final JButton button_1 = new JButton("2");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_1.setBackground(new Color(23,162,184));
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_1.setBackground(Color.DARK_GRAY);
			}
		});
		button_1.setForeground(new Color(255, 255, 255));
		button_1.setBackground(Color.DARK_GRAY);
		final JButton button_3 = new JButton("4");
		button_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_3.setBackground(new Color(23,162,184));
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_3.setBackground(Color.DARK_GRAY);
			}
		});
		button_3.setBackground(Color.DARK_GRAY);
		button_3.setForeground(new Color(255, 255, 255));
		final JButton button_4 = new JButton("6");
		button_4.setForeground(Color.WHITE);
		button_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_4.setBackground(new Color(23,162,184));
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_4.setBackground(Color.DARK_GRAY);
			}
		});
		button_4.setBackground(Color.DARK_GRAY);
		final JButton button_6 = new JButton("8");
		button_6.setForeground(Color.WHITE);
		button_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_6.setBackground(new Color(23,162,184));
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_6.setBackground(Color.DARK_GRAY);
			}
		});
		button_6.setBackground(Color.DARK_GRAY);
		final JButton button_8 = new JButton("10");
		button_8.setForeground(Color.WHITE);
		button_8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_8.setBackground(new Color(23,162,184));
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_8.setBackground(Color.DARK_GRAY);
			}
		});
		final JLabel chprseat = new JLabel("");
		button_8.setBackground(Color.DARK_GRAY);
		
		button_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					
					ttlseat.setText("2");
						chprseat.setText(value);
						int num=Integer.parseInt(value);
						total_bill=2*num;
						ttlbill.setText(Integer.toString(total_bill));
					}else if(evt.getKeyCode()==KeyEvent.VK_LEFT){
					//	button.requestFocus();
					}else if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
					//	button_2.requestFocus();
					}
			}
		});
		
		final JLabel taxx = new JLabel("  ");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				seatno="2";
				ttlseat.setText("2");
				chprseat.setText(val);
				//int num=Integer.parseInt(value);
				//int num=5;
				taxx.setText(tax);
				//int num1=200;
				if(val == "200")
				{
					expen="35";
					total_bill=(2*200)+50;
					ttl_bill=total_bill+"";
					//new Final(seatno,tax,val,ttl_bill,"35");
					
				}else if(val == "250")
				{
					total_bill=(2*250)+30;
					ttl_bill=total_bill+"";
					//new Final(seatno,tax,val,ttl_bill,"40");
				}else if(val == "400")
				{
					total_bill=(2*400)+90;
					ttl_bill=total_bill+"";
					//new Final(seatno,tax,val,ttl_bill,"70");
				}else if(val == "500")
				{
					total_bill=(2*500)+70;
					ttl_bill=total_bill+"";
					//new Final(seatno,tax,val,ttl_bill,"80");
				}
				
				ttlbill.setText(Integer.toString(total_bill));
				
				
			}
		});
		button_1.setBounds(10, 22, 49, 23);
		panel.add(button_1);
		
		
		button_3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					
					ttlseat.setText("4");
						chprseat.setText(value);
						int num=Integer.parseInt(value);
						total_bill=4*num;
						ttlbill.setText(Integer.toString(total_bill));
					}else if(evt.getKeyCode()==KeyEvent.VK_LEFT){
						//button_2.requestFocus();
					}else if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
						//button_7.requestFocus();
					}
			}
		});
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				seatno="4";
				ttlseat.setText("4");
				chprseat.setText(val);
				//int num=Integer.parseInt(value);
				//int num=5;
				taxx.setText(tax);
				//int num1=200;
				if(val == "200")
				{
					expen="35";
					total_bill=(2*200)+50;
					ttl_bill=total_bill+"";
					//new Final(seatno,tax,val,ttl_bill,"35");
					
				}else if(val == "250")
				{
					total_bill=(2*250)+30;
					ttl_bill=total_bill+"";
					//new Final(seatno,tax,val,ttl_bill,"40");
				}else if(val == "400")
				{
					total_bill=(2*400)+90;
					ttl_bill=total_bill+"";
					//new Final(seatno,tax,val,ttl_bill,"70");
				}else if(val == "500")
				{
					total_bill=(2*500)+70;
					ttl_bill=total_bill+"";
					//new Final(seatno,tax,val,ttl_bill,"80");
				}
				
				ttlbill.setText(Integer.toString(total_bill));
				
			}
		});
		button_3.setBorder(new EmptyBorder(10, 10, 10, 10));
		button_3.setBounds(65, 22, 49, 23);
		panel.add(button_3);
		
		
		button_4.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					
					ttlseat.setText("6");
						chprseat.setText(value);
						int num=Integer.parseInt(value);
						total_bill=6*num;
						ttlbill.setText(Integer.toString(total_bill));
					}else if(evt.getKeyCode()==KeyEvent.VK_LEFT){
						//button_7.requestFocus();
					}else if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
						//button_5.requestFocus();
					}
			}
		});
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				seatno="6";
				ttlseat.setText("6");
				chprseat.setText(val);
				//int num=Integer.parseInt(value);
				//int num=5;
				taxx.setText(tax);
				//int num1=200;
				if(val == "200")
				{
					total_bill=(6*200)+50;
					
				}else if(val == "250")
				{
					total_bill=(6*250)+30;
				}else if(val == "400")
				{
					total_bill=(6*400)+90;
				}else if(val == "500")
				{
					total_bill=(6*500)+70;
				}
				
				ttlbill.setText(Integer.toString(total_bill));
			}
		});
		button_4.setBorder(new EmptyBorder(10, 10, 10, 10));
		button_4.setBounds(125, 22, 48, 23);
		panel.add(button_4);
		
		
		button_6.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					
					ttlseat.setText("8");
						chprseat.setText(value);
						int num=Integer.parseInt(value);
						total_bill=8*num;
						ttlbill.setText(Integer.toString(total_bill));
					}else if(evt.getKeyCode()==KeyEvent.VK_LEFT){
						//button_5.requestFocus();
					}else if(evt.getKeyCode()==KeyEvent.VK_RIGHT){
						button_8.requestFocus();
					}
			}
		});
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				seatno="8";
				ttlseat.setText("8");
				chprseat.setText(val);
				//int num=Integer.parseInt(value);
				//int num=5;
				taxx.setText(tax);
				//int num1=200;
				if(val == "200")
				{
					total_bill=(8*200)+50;
					
				}else if(val == "250")
				{
					total_bill=(8*250)+30;
				}else if(val == "400")
				{
					total_bill=(8*400)+90;
				}else if(val == "500")
				{
					total_bill=(8*500)+70;
				}
				
				ttlbill.setText(Integer.toString(total_bill));
			}
		});
		button_6.setBounds(184, 22, 49, 23);
		panel.add(button_6);
		final JPanel panel_3 = new JPanel();
		
		button_8.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent evt) {
				if(evt.getKeyCode()==KeyEvent.VK_ENTER){
					
					ttlseat.setText("9");
						chprseat.setText(value);
						int num=Integer.parseInt(value);
						total_bill=9*num;
						ttlbill.setText(Integer.toString(total_bill));
					}else if(evt.getKeyCode()==KeyEvent.VK_LEFT){
						button_6.requestFocus();
					}
			}
		});
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				seatno="10";
				ttlseat.setText("10");
				chprseat.setText(val);
				//int num=Integer.parseInt(value);
				//int num=5;
				taxx.setText(tax);
				//int num1=200;
				if(val == "200")
				{
					total_bill=(10*200)+50;
					
				}else if(val == "250")
				{
					total_bill=(10*250)+30;
				}else if(val == "400")
				{
					total_bill=(10*400)+90;
				}else if(val == "500")
				{
					total_bill=(10*500)+70;
				}
				
				ttlbill.setText(Integer.toString(total_bill));
			}
		});
		button_8.setBorder(new EmptyBorder(10, 10, 10, 10));
		button_8.setBounds(237, 22, 49, 23);
		panel.add(button_8);
		
		JLabel lblNewLabel = new JLabel("Bill Details:");
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 16));
		lblNewLabel.setForeground(new Color(24,53,76));
		lblNewLabel.setBounds(23, 137, 109, 21);
		contentPanel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(24,53,76));
		panel_1.setBounds(57, 158, 296, 103);
		contentPanel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblTotalSeats = new JLabel("Total seats :");
		lblTotalSeats.setFont(new Font("Serif", Font.PLAIN, 15));
		lblTotalSeats.setForeground(Color.WHITE);
		lblTotalSeats.setBounds(10, 10, 80, 21);
		panel_1.add(lblTotalSeats);
		
		JLabel lblChargePerSeat = new JLabel("Charge per seat:");
		lblChargePerSeat.setFont(new Font("SansSerif", Font.PLAIN, 14));
		lblChargePerSeat.setForeground(Color.WHITE);
		lblChargePerSeat.setBounds(10, 29, 126, 20);
		panel_1.add(lblChargePerSeat);
		ttlbill.setForeground(Color.WHITE);
		
		
		ttlbill.setBackground(Color.YELLOW);
		ttlbill.setBounds(137, 76, 71, 16);
		panel_1.add(ttlbill);
		
		ttlseat.setForeground(Color.WHITE);
		
		
		ttlseat.setBackground(Color.BLACK);
		ttlseat.setBounds(136, 12, 59, 21);
		panel_1.add(ttlseat);
		{
			
			taxx.setForeground(Color.WHITE);
			taxx.setBounds(120, 56, 62, 16);
			panel_1.add(taxx);
		}
		
		JLabel lblTotalBill = new JLabel("Total Bill :");
		lblTotalBill.setBounds(10, 78, 71, 14);
		panel_1.add(lblTotalBill);
		lblTotalBill.setFont(new Font("Serif", Font.BOLD, 16));
		lblTotalBill.setForeground(Color.WHITE);
		
		JLabel lblNewLabel_1 = new JLabel("Tax :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(10, 53, 111, 21);
		panel_1.add(lblNewLabel_1);
		
		
		chprseat.setForeground(Color.WHITE);
		chprseat.setBounds(146, 34, 62, 15);
		panel_1.add(chprseat);
		
		JButton button_9 = new JButton("?");
		button_9.setBackground(Color.DARK_GRAY);
		button_9.setForeground(Color.WHITE);
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			String msg="Rates per seat :\n  1 Standard seat for Family : \t\t 200 \n  1 Standard seat for Bachelor : \t\t 250 \n 1 Premium seat for Family : \t 400 \n  1 Premium seat for Bachelor : \t 500";
			JOptionPane.showMessageDialog(null, msg);
			}
		});
		button_9.setBounds(282, 11, 45, 23);
		contentPanel.add(button_9);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(57, 263, 317, 28);
		contentPanel.add(panel_2);
		panel_2.setLayout(null);
		
		final JButton btnNewButton = new JButton("OK");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnNewButton.setBackground(Color.GREEN);
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				btnNewButton.setBackground(Color.DARK_GRAY);
			}
		});
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 14));
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(Color.DARK_GRAY);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//public void main(String[] args) {
					
				//}
				
				 int opt=JOptionPane.showConfirmDialog(null,"Do you confirm?","Yes", JOptionPane.YES_NO_OPTION);
				 
				 
					if (opt==0)
					{
						Final f=new Final(seatno,val,tax,ttl_bill,expen);
						f.dseat(seatno,val,tax,ttl_bill,expen);
						 new UserD().setVisible(true);
						 this.setVisible(false);
						 
						 
					}
			}

			private void setVisible(boolean b) {
				// TODO Auto-generated method stub
				
			}
		});
		btnNewButton.setBounds(145, 0, 58, 24);
		panel_2.add(btnNewButton);
		
		final JButton btnNewButton_1 = new JButton("Cancel");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				btnNewButton_1.setBackground(new Color(23,162,184));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_4.setBackground(Color.DARK_GRAY);
			}
			
		});
		btnNewButton_1.setFont(new Font("Serif", Font.BOLD, 14));
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(Color.DARK_GRAY);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int opt=JOptionPane.showConfirmDialog(null,"Do you want to cancel?","Yes", JOptionPane.YES_NO_OPTION);
				if (opt==0)
				{
					
					dispose();
					 
				}
			
			
			}

			private void setVisible(boolean b) {
				// TODO Auto-generated method stub
				
			}
		});
		btnNewButton_1.setBounds(226, 1, 81, 23);
		panel_2.add(btnNewButton_1);
		
		final JButton button_10 = new JButton("");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					int opt=JOptionPane.showConfirmDialog(null,"Do you want to close the program?","Yes", JOptionPane.YES_NO_OPTION);
					if (opt==0)
					{
						
						System.exit(0);
						 
					}
				
			}
		});
		button_10.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				button_10.setIcon(new ImageIcon(mani.class.getResource("logoffHoverr.jpeg")));
			}
			@Override
			public void mouseExited(MouseEvent arg0) {
				button_10.setIcon(new ImageIcon(mani.class.getResource("logoff.jpeg")));
			}
		});
		button_10.setIcon(new ImageIcon(mani.class.getResource("logoff.jpeg")));
		button_10.setBounds(337, 11, 37, 23);
		contentPanel.add(button_10);
	}
}
