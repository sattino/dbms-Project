import java.awt.BorderLayout;
import java.util.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;


public class Final extends javax.swing.JFrame {

	
	private JPanel contentPane;

    static String name;
    static String fname;
    static String cnic;
    static String phnum; 
    static String tbltype;
    static String type;
    static String from;
    static String to;
    static String tbl;
    static String seatno;
    static String tax;
    static String val;
    static String ttl_bill;
    static String expen;
    static String Id;
    static int count=0;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Final frame = new Final(name, fname, cnic, phnum," ");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	void userd(String var,String var1,String var2,String var3 )
	{
			this.name=var;
			this.fname=var1;   //type from to num
			this.cnic=var2;
			this.phnum=var3;
			
		}
	void dseat(String var,String var1,String var2,String var3 ,String var4)
	{
			this.seatno=var;
			this.val=var1;   //type from to num
			this.tax=var2;
			this.ttl_bill=var3;
			this.expen=var4;
		}
	void mani(String var,String var1,String var2,String var3 ,String var4)
	{
				this.tbltype=var;
				this.type=var1;   //type from to num
				this.from=var2;
				this.to=var3;
				this.tbl=var4;
			
		}
	public Final(String var,String var1,String var2,String var3 ,String var4) {
		count++;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 434, 261);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setBounds(86, 30, 51, 22);
		panel.add(lblName);
		
		JLabel lblM = new JLabel("m");
		lblM.setBounds(192, 32, 57, 18);
		panel.add(lblM);
		
		JLabel lblFatherName = new JLabel("Father name:");
		lblFatherName.setBounds(86, 63, 65, 14);
		panel.add(lblFatherName);
		
		
		
	}
	public void passValues()
	{
		Linklist l=new Linklist();
		l.insert(name, fname, cnic, phnum, tbltype, type, from, to, tbl, seatno, tax, val, ttl_bill, expen );
		//System.out.println("hello");
	}
}
